-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 24, 2025 at 02:11 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `acaflow`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adm_id` varchar(20) NOT NULL,
  `adm_password` varchar(255) NOT NULL,
  `adm_Fname` varchar(200) NOT NULL,
  `adm_Lname` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adm_id`, `adm_password`, `adm_Fname`, `adm_Lname`) VALUES
('88089989', '$2y$10$.ccIqlCmReyYxsN.47eCvuVM5eL9H.R7mNiJKWcjPI2r37L0mEizW', 'Admin', 'MIS');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_code` varchar(20) NOT NULL,
  `course_name` text NOT NULL,
  `year_level` int(11) NOT NULL,
  `semester` int(11) NOT NULL,
  `curriculum_year` int(11) NOT NULL,
  `department` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `dept_name` text NOT NULL,
  `dept_head` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`dept_name`, `dept_head`) VALUES
('College of Computer Studies', 'Carlo Petalver');

-- --------------------------------------------------------

--
-- Table structure for table `enrolled_courses`
--

CREATE TABLE `enrolled_courses` (
  `edp_code` varchar(10) NOT NULL,
  `st_id` varchar(20) NOT NULL,
  `tc_id` varchar(20) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Not Cleared',
  `remarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `offered_courses`
--

CREATE TABLE `offered_courses` (
  `edp_code` varchar(10) NOT NULL,
  `course_code` varchar(20) NOT NULL,
  `department` text NOT NULL,
  `assigned_tc_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `st_id` varchar(20) NOT NULL,
  `st_username` varchar(30) NOT NULL,
  `st_password` varchar(255) NOT NULL,
  `st_Fname` varchar(200) NOT NULL,
  `st_Lname` varchar(200) NOT NULL,
  `st_grade_level` int(11) NOT NULL,
  `st_department` text NOT NULL,
  `st_curriculum_year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`st_id`, `st_username`, `st_password`, `st_Fname`, `st_Lname`, `st_grade_level`, `st_department`, `st_curriculum_year`) VALUES
('23079569', 'st_23079569', '$2y$10$yr0qdrEh0CoUNULGDCXkauPFhw2oAwjX1l2eKnrp0NAwY71jh/XIC', 'James', 'Earl', 3, 'College of Computer Studies', 2021);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `tc_id` varchar(20) NOT NULL,
  `tc_username` varchar(30) NOT NULL,
  `tc_password` varchar(255) NOT NULL,
  `tc_Fname` varchar(200) NOT NULL,
  `tc_Lname` varchar(200) NOT NULL,
  `tc_department` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`tc_id`, `tc_username`, `tc_password`, `tc_Fname`, `tc_Lname`, `tc_department`) VALUES
('11234412', 'tc_11234412', '$2y$10$/7ZsYI3UBK3YJb3DLQNm2.YdiJAEoYzBgRD0nFQDIn00rY0Eksxrm', 'Teacher', 'One', 'College of Compute Studies');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
