<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Login</title>
    <link rel="icon" type="image/png" href="logo.png">
</head>
<style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f4;
        }
        form {
            width: 400px;
            padding: 2rem;
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
            border-radius: 10px;
            background: white;
            box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.2);
        }
        div {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        label {
            font-size: 18px;
        }
        input {
            font-size: 18px;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            padding: 15px;
            font-size: 18px;
            border: none;
            border-radius: 10px;
            background: #007BFF;
            color: white;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background: #0056b3;
        }
    </style>
<body>
    <form method="post">
    <div>
            <label for="id_input">Teacher ID</label>
            <input name="id_input" type="text" placeholder="23112345" required>
        </div>
        <div>
            <label for="username_input">Username</label>
            <input name="username_input" type="text" placeholder="TC_23112345" required>
        </div>
        <div>
            <label for="password_input">Password</label>
            <input name="password_input" type="password" placeholder="Enter 8 characters or more" required autocomplete="off">
        </div>
        <button type="submit">Login as Teacher</button>
    </form>
</body>
</html>
