<?php
$password = "admin123"; // Replace with the actual password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
echo $hashedPassword;
?>
