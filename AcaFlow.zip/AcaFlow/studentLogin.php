<?php
require __DIR__ . "/database/db_conn.php";
require __DIR__ . "/operations/st_operations.php";
require __DIR__ . "/prompt.php";

session_start();
$promptMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = trim($_POST['id_input']);
    $username = trim($_POST['username_input']);
    $password = $_POST['password_input'];

    $studentOps = new StudentOperations($pdo);
    $loginResult = $studentOps->login($student_id, $username, $password);

    if ($loginResult === true) {
        $_SESSION["student_id"] = $student_id;
        header("Location: studentsInterface/dashboard.php");
        exit();
    } else {
        $promptMessage = $loginResult;
        header("refresh:2");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login</title>
    <link rel="icon" type="image/png" href="logo.png">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f4;
        }
        .prompt {
            margin-bottom: 15px;
            padding: 10px;
            width: 400px;
            text-align: center;
            border-radius: 5px;
            background: #ffdddd;
            color: #a94442;
            display: <?php echo empty($promptMessage) ? 'none' : 'block'; ?>;
        }
        form {
            width: 400px;
            padding: 2rem;
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
            border-radius: 10px;
            background: white;
            box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.2);
        }
        div {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        label {
            font-size: 18px;
        }
        input {
            font-size: 18px;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            padding: 15px;
            font-size: 18px;
            border: none;
            border-radius: 10px;
            background: #007BFF;
            color: white;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>

    <div class="prompt"><?php echo $promptMessage; ?></div>

    <form method="post">
        <div>
            <label for="id_input">Student ID</label>
            <input name="id_input" type="text" placeholder="23112345" required>
        </div>
        <div>
            <label for="username_input">Username</label>
            <input name="username_input" type="text" placeholder="ST_23112345" required>
        </div>
        <div>
            <label for="password_input">Password</label>
            <input name="password_input" type="password" placeholder="Enter 8 characters or more" required autocomplete="off">
        </div>
        <button type="submit">Login as Student</button>
    </form>

</body>
</html>
