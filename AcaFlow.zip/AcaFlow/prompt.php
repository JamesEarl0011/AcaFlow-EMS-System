<?php
function showPrompt($message, $type = "info") {
    echo "<div class='prompt $type'>$message</div>";
}
?>

<style>
    .prompt {
        width: fit-content;
        max-width: 400px;
        padding: 15px;
        margin: 10px auto;
        border-radius: 10px;
        text-align: center;
        font-size: 18px;
        font-weight: bold;
        box-shadow: 3px 3px 10px rgba(0,0,0,0.1);
    }
    .success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    .warning { background-color: #fff3cd; color: #856404; border: 1px solid #ffeeba; }
    .info { background-color: #cce5ff; color: #004085; border: 1px solid #b8daff; }
</style>
