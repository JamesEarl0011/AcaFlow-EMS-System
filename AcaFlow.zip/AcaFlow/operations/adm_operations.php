<?php
require __DIR__ . "/../database/db_conn.php";

class AdminOperations {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Admin login method with detailed error handling
    public function login($admin_id, $password) {
        $stmt = $this->pdo->prepare("SELECT adm_password FROM admins WHERE adm_id = ?");
        $stmt->execute([$admin_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            return "Admin ID not found.";
        }

        if (!password_verify($password, $user['adm_password'])) {
            return "Incorrect password.";
        }

        return true;
    }
}
?>
