<?php
require __DIR__ . "/../database/db_conn.php";

class TeacherOperations {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Teacher login method with detailed error handling
    public function login($teacher_id, $username, $password) {
        $stmt = $this->pdo->prepare("SELECT tc_password FROM teachers WHERE tc_id = ? AND tc_username = ?");
        $stmt->execute([$teacher_id, $username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            return "Teacher ID or Username not found.";
        }

        if (!password_verify($password, $user['tc_password'])) {
            return "Incorrect password.";
        }

        return true;
    }
}
?>
