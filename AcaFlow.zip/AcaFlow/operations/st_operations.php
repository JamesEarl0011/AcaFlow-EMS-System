<?php
require __DIR__ . "/../database/db_conn.php";

class StudentOperations {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Student login method with detailed error handling
    public function login($student_id, $username, $password) {
        $stmt = $this->pdo->prepare("SELECT st_password FROM students WHERE st_id = ? AND st_username = ?");
        $stmt->execute([$student_id, $username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            return "Student ID or Username not found.";
        }

        if (!password_verify($password, $user['st_password'])) {
            return "Incorrect password.";
        }

        return true;
    }
}
