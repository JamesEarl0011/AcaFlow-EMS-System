<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Login</title>
    <link rel="icon" type="image/png" href="logo.png">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #06a77d;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #052f5f;
        }
        form {
            background: #005377;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 6px 10px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
        }
        .inp {
            margin-bottom: 1.25rem;
            display: flex;
            flex-direction: column;
        }
        label {
            font-size: 0.95rem;
            margin-bottom: 0.5rem;
            color: #d5c67a;
        }
        input[type="text"],
        input[type="password"] {
            padding: 0.85rem;
            font-size: 1rem;
            border: none;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.1);
            color: #052f5f;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        input[type="text"]:focus,
        input[type="password"]:focus {
            background: rgba(255, 255, 255, 0.2);
            transform: scale(1.02);
            outline: none;
        }
        button {
            background-color: #d5c67a;
            color: #052f5f;
            border: none;
            padding: 0.9rem;
            font-size: 1rem;
            border-radius: 8px;
            cursor: pointer;
            width: 100%;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        button:hover {
            background-color: #b8ab5e;
            transform: scale(1.02);
        }
        .back-button {
            display: inline-block;
            margin-top: 1rem;
            background: none;
            border: 2px solid #d5c67a;
            color: #d5c67a;
            padding: 0.7rem 1rem;
            font-size: 0.9rem;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        .back-button:hover {
            background-color: #d5c67a;
            color: #052f5f;
        }
        ::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
    </style>
</head>
<body>
    <form method="post" id="login_Form">
        <div class="inp top">
            <label for="id_Input">ID number</label>
            <input type="text" name="id_Input" id="id_Input" placeholder="Enter your ID number">
        </div>
        <div class="inp middle">
            <label for="username_Input">Username</label>
            <input type="text" name="username_Input" id="username_Input" placeholder="Enter your username">
        </div>
        <div class="inp bottom">
            <label for="password_Input">Password</label>
            <input type="password" name="password_Input" id="password_Input" placeholder="Enter your password">
        </div>
        <button type="submit">Login as Teacher</button>
        <button type="button" class="back-button" onclick="window.location.href='index.html'">Back to Home</button>
    </form>
</body>
</html>