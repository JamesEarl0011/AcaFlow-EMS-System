<?php
session_start();
require __DIR__ . "/../database/connection.php";
require __DIR__ . "/adminOperations.php";
require __DIR__ . "/../prompt.php";

if (!isset($_SESSION['adm_id'])) {
    header("Location: login.php");
    exit();
}

$adm_id = $_SESSION["adm_id"];
$adminOps = new AdminOperations($pdo);

$searchQuery = isset($_POST['search']) ? trim($_POST['search']) : "";
$payments = $adminOps->getStudentPayments($searchQuery);

$message = "";
$alertType = ""; // success or error

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["username"])) {
        // Profile Update Logic
        $adm_id = $_SESSION['adm_id'];
        $username = trim($_POST["username"]);
        $password = trim($_POST["password"]);
        $first_name = trim($_POST["first_name"]);
        $last_name = trim($_POST["last_name"]);
        $email = trim($_POST["email"]);

        if ($adminOps->updateAccountingAdminAccount($adm_id, $username, $password, $first_name, $last_name, $email)) {
            $_SESSION["success_message"] = "Profile updated successfully.";
        } else {
            $_SESSION["error_message"] = "Failed to update profile.";
        }

        header("Location: Accounting_dashboard.php");
        exit();
    } 

    if (isset($_POST["student_id"])) {
        // Payment Update Logic
        $student_id = $_POST['student_id']; 
        $midterms_status = $_POST['midterms_status'];
        $finals_status = $_POST['finals_status'];
        $changed_by = $adm_id;

        if ($adminOps->updateStudentPayment($student_id, $midterms_status, $finals_status, $changed_by)) {
            $message = "Payment updated successfully.";
            $alertType = "success";
        } else {
            $message = "Failed to update payment.";
            $alertType = "error";
        }

        showPrompt($message, $alertType);
        header("refresh: 3");
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accounting Dashboard</title>
    <link rel="icon" type="image/png" href="../images/logo.png">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #06a77d;
            color: #052f5f;
        }
        .sidebar {
            width: 250px;
            background-color: #005377;
            color: #d5c67a;
            height: 100vh;
            position: fixed;
            display: flex;
            flex-direction: column;
            gap: 10px;
            padding-top: 20px;
        }
        .sidebar a {
            color: #d5c67a;
            text-decoration: none;
            padding: 15px;
            display: block;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            transition: background-color 0.3s ease;
        }
        .sidebar a:hover {
            background-color: #d5c67a;
            color: #052f5f;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
            background: #f4f9f9;
            min-height: 100vh;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <center><h2>Registrar Dashboard</h2></center>
    <a href="Registrar_dashboard.php">Dashboard</a>
    <a href="#">Profile</a>
    <a href="#"">Add Student Evaluation</a>
    <a href="#"">Confirm Enrollment</a>
    
    <a href="logout.php">Logout</a>
</div>

<!-- Prompt for Success/Error -->
<?php
    if (!empty($message)) {
        echo "<script>showPrompt('$message', '$alertType');</script>";
    }
?>

<div class="main-content">
    <h2>Registrar Dashboard</h2>


</body>
</html>
