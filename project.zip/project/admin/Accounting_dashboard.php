<?php
session_start();
require __DIR__ . "/../database/connection.php";
require __DIR__ . "/adminOperations.php";
require __DIR__ . "/../prompt.php";

if (!isset($_SESSION['adm_id'])) {
    header("Location: login.php");
    exit();
}

$adm_id = $_SESSION["adm_id"];
$adminOps = new AdminOperations($pdo);

$searchQuery = isset($_POST['search']) ? trim($_POST['search']) : "";
$payments = $adminOps->getStudentPayments($searchQuery);

$message = "";
$alertType = ""; // success or error

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["username"])) {
        // Profile Update Logic
        $adm_id = $_SESSION['adm_id'];
        $username = trim($_POST["username"]);
        $password = trim($_POST["password"]);
        $first_name = trim($_POST["first_name"]);
        $last_name = trim($_POST["last_name"]);
        $email = trim($_POST["email"]);

        if ($adminOps->updateAccountingAdminAccount($adm_id, $username, $password, $first_name, $last_name, $email)) {
            $_SESSION["success_message"] = "Profile updated successfully.";
        } else {
            $_SESSION["error_message"] = "Failed to update profile.";
        }

        header("Location: Accounting_dashboard.php");
        exit();
    } 

    if (isset($_POST["student_id"])) {
        // Payment Update Logic
        $student_id = $_POST['student_id']; 
        $midterms_status = $_POST['midterms_status'];
        $finals_status = $_POST['finals_status'];
        $changed_by = $adm_id;

        if ($adminOps->updateStudentPayment($student_id, $midterms_status, $finals_status, $changed_by)) {
            $message = "Payment updated successfully.";
            $alertType = "success";
        } else {
            $message = "Failed to update payment.";
            $alertType = "error";
        }

        showPrompt($message, $alertType);
        header("refresh: 3");
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accounting Dashboard</title>
    <link rel="icon" type="image/png" href="../logo.png">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #06a77d;
            color: #052f5f;
        }
        .sidebar {
            width: 250px;
            background-color: #005377;
            color: #d5c67a;
            height: 100vh;
            position: fixed;
            display: flex;
            flex-direction: column;
            gap: 10px;
            padding-top: 20px;
        }
        .sidebar a {
            color: #d5c67a;
            text-decoration: none;
            padding: 15px;
            display: block;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            transition: background-color 0.3s ease;
        }
        .sidebar a:hover {
            background-color: #d5c67a;
            color: #052f5f;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
            background: #f4f9f9;
            min-height: 100vh;
        }
        .search-bar {
            margin-bottom: 10px;
        }
        .search-bar input {
            padding: 8px;
            width: 250px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .search-bar button {
            padding: 8px 12px;
            border: none;
            background-color: #005377;
            color: #fff;
            cursor: pointer;
            border-radius: 5px;
        }
        .search-bar button:hover {
            background-color: #d5c67a;
            color: #052f5f;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: #d5c67a;
            color: #052f5f;
        }
        .paid {
            color: green;
            font-weight: bold;
        }
        .pending {
            color: red;
            font-weight: bold;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: white;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #ddd;
            width: 30%;
            text-align: center;
            border-radius: 10px;
        }
        .modal-content form{
            align-items: center;
            display: flex;
            flex-direction: column;
            gap: 10px
        }
        .close {
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <center><h2>Accounting Dashboard</h2></center>
    <a href="Accounting_dashboard.php">Dashboard</a>
    <a href="#" onclick="openModal()">Update Payment</a>
    <a href="#" onclick="openProfileModal()">Update Profile</a>
    <a href="logout.php">Logout</a>
</div>

<!-- Prompt for Success/Error -->
<?php
    if (!empty($message)) {
        echo "<script>showPrompt('$message', '$alertType');</script>";
    }
?>

<div class="main-content">
    <h2>Accounting Dashboard</h2>
    
<!-- Modal for Updating Profile -->
    <div id="profileModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeProfileModal()">&times;</span>
            <h3>Update Profile</h3>
            <form method="POST" action="updateProfile.php">
                <label for="username">Username: <input type="text" id="username" name="username" required></label>
                <label for="password">Password: <input type="password" id="password" name="password" required></label>
                <label for="first_name">First Name: <input type="text" id="first_name" name="first_name" required></label>
                <label for="last_name">Last Name: <input type="text" id="last_name" name="last_name" required></label>
                <label for="email">Email: <input type="email" id="email" name="email" required></label>
                <button type="submit">Save Changes</button>
            </form>
        </div>
    </div>

<!-- Modal for Updating Payments -->
    <div id="updateModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h3>Update Payment</h3>
            <form method="POST">
                <label for="student_id">Student ID:<input type="text" id="student_id" name="student_id" required></label>
                <label for="midterms_status">Midterms Payment:
                    <select id="midterms_status" name="midterms_status">
                        <option value="Paid">Paid</option>
                        <option value="Pending">Pending</option>
                    </select>
                </label>
                <label for="finals_status">Finals Payment:
                    <select id="finals_status" name="finals_status">
                        <option value="Paid">Paid</option>
                        <option value="Pending">Pending</option>
                    </select>
                </label>
                <button type="submit">Update</button>
            </form>
        </div>
    </div>

<!-- Search Bar -->
    <form method="POST" action="Accounting_dashboard.php" class="search-bar">
        <input type="text" name="search" placeholder="Search by Student ID" value="<?php echo htmlspecialchars($searchQuery); ?>">
        <button type="submit">Search</button>
    </form>

    <h3>Student Payment Records</h3>
    <table>
        <tr>
            <th>Student ID</th>
            <th>Total Due</th>
            <th>Midterms</th>
            <th>Finals</th>
            <th>Grade Portal Access</th>
        </tr>
        <?php if (empty($payments)): ?>
            <tr><td colspan="5">No records found.</td></tr>
        <?php else: ?>
            <?php foreach ($payments as $payment): ?>
                <tr>
                    <td><?php echo htmlspecialchars($payment['st_id']); ?></td>
                    <td>₱<?php echo number_format($payment['total_due'], 2); ?></td>
                    <td class="<?php echo ($payment['midterms_payment_status'] == 'Paid') ? 'paid' : 'pending'; ?>">
                        <?php echo $payment['midterms_payment_status']; ?>
                    </td>
                    <td class="<?php echo ($payment['finals_payment_status'] == 'Paid') ? 'paid' : 'pending'; ?>">
                        <?php echo $payment['finals_payment_status']; ?>
                    </td>
                    <td>
                        <?php 
                            if ($payment['midterms_payment_status'] == 'Paid' && $payment['finals_payment_status'] == 'Paid') {
                                echo "<span class='paid'>Granted</span>";
                            } elseif ($payment['midterms_payment_status'] == 'Paid') {
                                echo "<span class='paid'>Midterm Only</span>";
                            } else {
                                echo "<span class='pending'>Restricted</span>";
                            }
                        ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </table>
</div>

<script>
    function openModal() { document.getElementById("updateModal").style.display = "block"; }
    function closeModal() { document.getElementById("updateModal").style.display = "none"; }
    function openProfileModal() { document.getElementById("profileModal").style.display = "block"; }
    function closeProfileModal() { document.getElementById("profileModal").style.display = "none"; }
</script>

</body>
</html>
