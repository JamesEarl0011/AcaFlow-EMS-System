<?php 
    require __DIR__ . "/../database/connection.php";
    
    class AdminOperations{
        private $pdo;

        public function __construct($pdo) {
            $this->pdo = $pdo;
        }
// ! Login method
        public function loginAdmin($username, $password) {
            $sql = "SELECT * FROM admins WHERE username = :username";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(":username", $username);
            $stmt->execute();
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        
            if (!$admin) {
                return "Username not found.";
            }
        
            if (!password_verify($password, $admin['password'])) {
                return "Incorrect password.";
            }
        
            session_start();
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            return true; // Login successful
        }
        
    }
?>