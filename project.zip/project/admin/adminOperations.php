<?php 
require __DIR__ . "/../database/connection.php";

class AdminOperations {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

// ! Login method with role based redirection
    public function loginAdmin($adm_id, $password) {
        $sql = "SELECT * FROM admins WHERE adm_id = :adm_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(":adm_id", $adm_id);
        $stmt->execute();
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$admin) {
            return "Admin ID not found.";
        }

        if (!password_verify($password, $admin['hashed_password'])) {
            return "Incorrect password.";
        }

        session_start();
        $_SESSION['adm_id'] = $admin['adm_id'];
        $_SESSION['role'] = $admin['role']; // Store role in session

        // Redirect based on role
        switch ($admin['role']) {
            case 'Registrar':
                header("Location: admin/Registrar_dashboard.php");
                break;
            case 'Accounting':
                header("Location: admin/Accounting_dashboard.php");
                break;
            case 'MIS':
                header("Location: admin/MIS_dashboard.php");
                break;
            default:
                return "Invalid role assigned.";
        }
        exit();
    }

// ! Accounting methods

    // ! method to fetch all student payments
    public function getStudentPayments($search = "") {
        $sql = "SELECT st_id, total_due, midterms_due, finals_due,
                       midterms_payment_status, finals_payment_status
                FROM payments";
    
        if (!empty($search)) {
            $sql .= " WHERE st_id LIKE :search";
        }
    
        $stmt = $this->pdo->prepare($sql);
        
        if (!empty($search)) {
            $search = "%$search%";
            $stmt->bindParam(":search", $search, PDO::PARAM_STR);
        }
    
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // ! method to udpate payment of a student
    public function updateStudentPayment($student_id, $midterms_status, $finals_status, $adm_id) {
        $sql = "UPDATE payments 
                SET midterms_payment_status = :midterms_status, 
                    finals_payment_status = :finals_status,
                    changed_by = :adm_id 
                WHERE st_id = :student_id";
    
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':student_id', $student_id, PDO::PARAM_STR);
        $stmt->bindParam(':midterms_status', $midterms_status, PDO::PARAM_STR);
        $stmt->bindParam(':finals_status', $finals_status, PDO::PARAM_STR);
        $stmt->bindParam(':adm_id', $adm_id, PDO::PARAM_STR);
    
        return $stmt->execute();
    }
    
    // ! method to update Accounting Admin Account
    public function updateAccountingAdminAccount($adm_id, $username, $password, $first_name, $last_name, $email) {
        try {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $query = "UPDATE admins SET username = :username, password = :password, first_name = :first_name, last_name = :last_name, email = :email WHERE adm_id = :adm_id";
            $stmt = $this->pdo->prepare($query);
            $stmt->bindParam(":username", $username);
            $stmt->bindParam(":password", $hashedPassword);
            $stmt->bindParam(":first_name", $first_name);
            $stmt->bindParam(":last_name", $last_name);
            $stmt->bindParam(":email", $email);
            $stmt->bindParam(":adm_id", $adm_id);
            
            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }
// ! MIS methods
    // ! method to fetch users
    function fetchUsers($pdo, $searchQuery = "", $filterRole = "students") {
        $searchQuery = "%$searchQuery%";
        $users = [];
    
        if ($filterRole === "students") {
            $sql = "SELECT s.st_id, 
                           CONCAT(d.last_name, ', ', d.first_name, ' ', COALESCE(d.middle_initial, '')) AS name, 
                           d.program_enrolled 
                    FROM students s
                    JOIN demographic_profile d ON s.st_id = d.st_id
                    WHERE s.st_id LIKE ? OR d.last_name LIKE ?";
        } elseif ($filterRole === "teachers") {
            $sql = "SELECT tc_id, 
                           CONCAT(last_name, ', ', first_name) AS name, 
                           department 
                    FROM teachers 
                    WHERE tc_id LIKE ? OR last_name LIKE ?";
        } elseif ($filterRole === "admins") {
            $sql = "SELECT adm_id, 
                           CONCAT(last_name, ', ', first_name) AS name, 
                           role 
                    FROM admins 
                    WHERE adm_id LIKE ? OR last_name LIKE ?";
        } else {
            return $users;
        }
    
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$searchQuery, $searchQuery]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }    
    
    // ! Method to fetch offered courses (with optional search by EDP Code)
    public function fetchOfferedCourses($searchQuery = "") {
        $sql = "SELECT oc.edp_code, 
                       oc.course_code, 
                       c.course_description, 
                       oc.scheduled_days, 
                       TIME_FORMAT(oc.scheduled_start, '%h:%i %p') AS start_time, 
                       TIME_FORMAT(oc.scheduled_end, '%h:%i %p') AS end_time,
                       IFNULL(CONCAT(t.last_name, ', ', t.first_name), 'No teacher assigned yet') AS teacher_assigned
                FROM offered_courses AS oc
                JOIN courses AS c ON oc.course_code = c.course_code
                JOIN assigned_courses AS ac ON oc.edp_code = ac.edp_code
                JOIN teachers AS t ON ac.tc_assigned = t.tc_id";
    
        if (!empty($searchQuery)) {
            $sql .= " WHERE oc.edp_code LIKE :searchQuery";
        }
    
        $stmt = $this->pdo->prepare($sql);
    
        if (!empty($searchQuery)) {
            $searchParam = "%$searchQuery%";
            $stmt->bindParam(":searchQuery", $searchParam, PDO::PARAM_STR);
        }
    
        $stmt->execute();
        $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
        // Format schedule properly
        foreach ($courses as &$course) {
            $course['schedule'] = "{$course['scheduled_days']} {$course['start_time']} - {$course['end_time']}";
        }
    
        return $courses;
    }
    
    // ! method to assign teacher to courses
    public function assignTeacherToCourse($edp_code, $tc_id, $adm_id, $password) {
        try {
            // Step 1: Verify the admin's password
            $stmt = $this->pdo->prepare("SELECT hashed_password FROM admins WHERE adm_id = :adm_id");
            $stmt->execute([':adm_id' => $adm_id]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
            if (!$admin) {
                return "Admin not found."; // Specific error message
            }
    
            if (!password_verify($password, $admin['hashed_password'])) {
                return "Failed to assign teacher. You've inputted an incorrect password."; // Specific error message
            }
    
            // Step 2: Check if the course already has an assigned teacher
            $stmt = $this->pdo->prepare("SELECT * FROM assigned_courses WHERE edp_code = :edp_code");
            $stmt->execute([':edp_code' => $edp_code]);
            $existingAssignment = $stmt->fetch(PDO::FETCH_ASSOC);
    
            if ($existingAssignment) {
                // Update the existing record
                $stmt = $this->pdo->prepare("
                    UPDATE assigned_courses
                    SET tc_assigned = :tc_assigned, admin_responsible = :admin_responsible
                    WHERE edp_code = :edp_code
                ");
                $stmt->execute([
                    ':tc_assigned' => $tc_id,
                    ':admin_responsible' => $adm_id,
                    ':edp_code' => $edp_code
                ]);
            } else {
                // Insert a new record
                $stmt = $this->pdo->prepare("
                    INSERT INTO assigned_courses (edp_code, tc_assigned, admin_responsible)
                    VALUES (:edp_code, :tc_assigned, :admin_responsible)
                ");
                $stmt->execute([
                    ':edp_code' => $edp_code,
                    ':tc_assigned' => $tc_id,
                    ':admin_responsible' => $adm_id
                ]);
            }
    
            return true; // Success
        } catch (Exception $e) {
            error_log("Error assigning teacher: " . $e->getMessage());
            return "Failed to assign teacher. Please try again."; // Generic error message for other exceptions
        }
    }

    // ! method to enroll students
    public function enrollStudents($edp_code, $student_ids, $adm_id) {
        try {
            //? Step 1: Verify the EDP code exists
            $courses = $this->fetchOfferedCourses($edp_code);
            $courseDetails = null;

            foreach ($courses as $course) {
                if ($course['edp_code'] === $edp_code) {
                    $courseDetails = $course;
                    break;
                }
            }

            if (!$courseDetails) {
                return "Invalid EDP Code.";
            }

            //? Step 2: Enroll each student
            $enrolledStudents = [];
            foreach ($student_ids as $student_id) {
                $stmt = $this->pdo->prepare("
                    INSERT INTO enrolled_students (edp_code, st_id, enrolled_by)
                    VALUES (:edp_code, :st_id, :enrolled_by)
                ");
                $stmt->execute([
                    ':edp_code' => $edp_code,
                    ':st_id' => $student_id,
                    ':enrolled_by' => $adm_id
                ]);
                $enrolledStudents[] = $student_id;
            }

            return [
                'edp_code' => $edp_code,
                'course_code' => $courseDetails['course_code'],
                'course_description' => $courseDetails['course_description'],
                'students' => $enrolledStudents
            ];
        } catch (Exception $e) {
            error_log("Error enrolling students: " . $e->getMessage());
            return "Failed to enroll students. Please try again.";
        }
    }
}
?>