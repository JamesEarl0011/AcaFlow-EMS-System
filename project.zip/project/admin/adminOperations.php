<?php 
require __DIR__ . "/../database/connection.php";

class AdminOperations {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

// ! Login method with role based redirection
    public function loginAdmin($adm_id, $password) {
        $sql = "SELECT * FROM admins WHERE adm_id = :adm_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(":adm_id", $adm_id);
        $stmt->execute();
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$admin) {
            return "Admin ID not found.";
        }

        if (!password_verify($password, $admin['hashed_password'])) {
            return "Incorrect password.";
        }

        session_start();
        $_SESSION['adm_id'] = $admin['adm_id'];
        $_SESSION['role'] = $admin['role']; // Store role in session

        // Redirect based on role
        switch ($admin['role']) {
            case 'Registrar':
                header("Location: admin/Registrar_dashboard.php");
                break;
            case 'Accounting':
                header("Location: admin/Accounting_dashboard.php");
                break;
            case 'MIS':
                header("Location: admin/MIS_dashboard.php");
                break;
            default:
                return "Invalid role assigned.";
        }
        exit();
    }

// ! Accounting methods

    // ! method to fetch all student payments
    public function getStudentPayments($search = "") {
        $sql = "SELECT st_id, total_due, midterms_due, finals_due,
                       midterms_payment_status, finals_payment_status
                FROM payments";
    
        if (!empty($search)) {
            $sql .= " WHERE st_id LIKE :search";
        }
    
        $stmt = $this->pdo->prepare($sql);
        
        if (!empty($search)) {
            $search = "%$search%";
            $stmt->bindParam(":search", $search, PDO::PARAM_STR);
        }
    
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // ! method to udpate payment of a student
    public function updateStudentPayment($student_id, $midterms_status, $finals_status, $adm_id) {
        $sql = "UPDATE payments 
                SET midterms_payment_status = :midterms_status, 
                    finals_payment_status = :finals_status,
                    changed_by = :adm_id 
                WHERE st_id = :student_id";
    
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':student_id', $student_id, PDO::PARAM_STR);
        $stmt->bindParam(':midterms_status', $midterms_status, PDO::PARAM_STR);
        $stmt->bindParam(':finals_status', $finals_status, PDO::PARAM_STR);
        $stmt->bindParam(':adm_id', $adm_id, PDO::PARAM_STR);
    
        return $stmt->execute();
    }
    
    // ! method to update Accounting Admin Account
    public function updateAccountingAdminAccount($adm_id, $username, $password, $first_name, $last_name, $email) {
        try {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $query = "UPDATE admins SET username = :username, password = :password, first_name = :first_name, last_name = :last_name, email = :email WHERE adm_id = :adm_id";
            $stmt = $this->pdo->prepare($query);
            $stmt->bindParam(":username", $username);
            $stmt->bindParam(":password", $hashedPassword);
            $stmt->bindParam(":first_name", $first_name);
            $stmt->bindParam(":last_name", $last_name);
            $stmt->bindParam(":email", $email);
            $stmt->bindParam(":adm_id", $adm_id);
            
            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }
    

}
?>
