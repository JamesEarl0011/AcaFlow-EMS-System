<?php
session_start();
require __DIR__ . "/../database/connection.php";
require __DIR__ . "/adminOperations.php";
require __DIR__ . "/../prompt.php";

if (!isset($_SESSION['adm_id'])) {
    header("Location: login.php");
    exit();
}

$adminOps = new AdminOperations($pdo);

$section = $_GET['section'] ?? 'users';
$type = $_GET['type'] ?? 'students';
$search = $_GET['search'] ?? '';

// Handle Assign Teacher Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_teacher'])) {
    $edp_code = $_POST['edp_code'];
    $tc_id = $_POST['tc_id'];
    $adm_id = $_SESSION['adm_id'];
    $password = $_POST['password'];

    $result = $adminOps->assignTeacherToCourse($edp_code, $tc_id, $adm_id, $password);
    if ($result === true) {
        showPrompt("Teacher assigned successfully!", "success");
    } else {
        showPrompt($result, "error"); // Display the specific error message
    }
}
// Handle Enroll Students Form Submission



// Fetch data based on the selected section
if ($section === "users") {
    $users = $adminOps->fetchUsers($pdo, $search, $type);

    $tableHeaders = [];
    if ($type === "students") {
        $tableHeaders = ["Student ID", "Name", "Program Enrolled"];
    } elseif ($type === "teachers") {
        $tableHeaders = ["Teacher ID", "Name", "Department"];
    } elseif ($type === "admins") {
        $tableHeaders = ["Admin ID", "Name", "Role"];
    }
} elseif ($section === "courses") {
    $courses = $adminOps->fetchOfferedCourses($search);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MIS Dashboard</title>
    <link rel="icon" type="image/png" href="../images/logo.png">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #06a77d;
            color: #052f5f;
        }
        .sidebar {
            width: 250px;
            background-color: #005377;
            color: #d5c67a;
            height: 100vh;
            position: fixed;
            display: flex;
            flex-direction: column;
            gap: 10px;
            padding-top: 20px;
        }
        .sidebar a {
            color: #d5c67a;
            text-decoration: none;
            padding: 15px;
            display: block;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            transition: background-color 0.3s ease;
        }
        .sidebar a:hover {
            background-color: #d5c67a;
            color: #052f5f;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
            background: #f4f9f9;
            min-height: 100vh;
        }
        .search-bar {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
        }
        .search-bar input, .search-bar select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .search-bar button {
            padding: 8px 12px;
            border: none;
            background-color: #005377;
            color: #fff;
            cursor: pointer;
            border-radius: 5px;
        }
        .search-bar button:hover {
            background-color: #d5c67a;
            color: #052f5f;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: #d5c67a;
            color: #052f5f;
        }
        .action-btn {
            padding: 6px 12px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .assign-teacher {
            background-color: #007BFF;
            color: #fff;
        }
        .assign-teacher:hover {
            background-color: #0056b3;
        }
        .enroll-student {
            background-color: #28A745;
            color: #fff;
        }
        .enroll-student:hover {
            background-color: #1e7e34;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: white;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #ddd;
            width: 30%;
            text-align: center;
            border-radius: 10px;
        }
        .modal-content form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .close {
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <center><h2>MIS Dashboard</h2></center>
    <a href="MIS_dashboard.php?section=users">Users</a>
    <a href="MIS_dashboard.php?section=courses">Offered Courses</a>
    <a href="logout.php">Logout</a>
</div>

<div class="main-content">
    <?php if ($section === "users"): ?>
        <h2>Users Management</h2>
        <form method="GET" action="MIS_dashboard.php" class="search-bar">
            <input type="hidden" name="section" value="users">
            <input type="text" name="search" placeholder="Search by ID or Last Name" value="<?= htmlspecialchars($search) ?>">
            <select name="type">
                <option value="students" <?= $type === "students" ? "selected" : "" ?>>Students</option>
                <option value="teachers" <?= $type === "teachers" ? "selected" : "" ?>>Teachers</option>
                <option value="admins" <?= $type === "admins" ? "selected" : "" ?>>Admins</option>
            </select>
            <button type="submit">Search</button>
        </form>
        <table>
            <tr>
                <?php foreach ($tableHeaders as $header): ?>
                    <th><?= $header ?></th>
                <?php endforeach; ?>
            </tr>
            <?php foreach ($users as $user): ?>
                <tr>
                    <?php foreach ($user as $value): ?>
                        <td><?= htmlspecialchars($value) ?></td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
    
    <?php if ($section === "courses"): ?>
        <h2>Offered Courses</h2>

        <form method="GET" action="MIS_dashboard.php" class="search-bar">
            <input type="hidden" name="section" value="courses">
            <input type="text" name="search" placeholder="Search by EDP Code" value="<?= htmlspecialchars($search) ?>">
            <button type="submit">Search</button>
        </form>

        <table>
            <tr>
                <th>EDP Code</th>
                <th>Course Code</th>
                <th>Course Description</th>
                <th>Schedule</th>
                <th>Teacher Assigned</th>
                <th>Actions</th>
            </tr>

            <?php foreach ($courses as $course): ?>
                <tr>
                    <td><?= htmlspecialchars($course['edp_code']) ?></td>
                    <td><?= htmlspecialchars($course['course_code']) ?></td>
                    <td><?= htmlspecialchars($course['course_description']) ?></td>
                    <td><?= htmlspecialchars($course['schedule']) ?></td>
                    <td><?= htmlspecialchars($course['teacher_assigned']) ?></td>
                    <td>
                        <button class="action-btn assign-teacher" onclick="openAssignTeacherModal('<?= $course['edp_code'] ?>')">Assign Teacher</button>
                        <button class="action-btn enroll-student" onclick="openStudentEnrollmentModal('<?= $course['edp_code'] ?>', '<?= $course['course_code'] ?>', '<?= $course['course_description'] ?>')">Enroll Students</button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</div>

<!-- Modal for Assigning Teacher -->
<div id="assignTeacherModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeAssignTeacherModal()">&times;</span>
        <h3>Assign Teacher</h3>
        <form method="POST" action="MIS_dashboard.php">
            <input type="hidden" id="edp_code" name="edp_code">
            <input type="hidden" name="adm_id" value="<?= $_SESSION['adm_id'] ?>">
            
            <label for="tc_id">Select Teacher:</label>
            <select name="tc_id" id="tc_id" required>
                <?php
                // Fetch all active teachers
                $stmt = $pdo->prepare("SELECT tc_id, first_name, last_name FROM teachers WHERE status = 'Active'");
                $stmt->execute();
                $teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

                foreach ($teachers as $teacher) {
                    echo "<option value='{$teacher['tc_id']}'>{$teacher['last_name']}, {$teacher['first_name']}</option>";
                }
                ?>
            </select>

            <label for="password">Confirm Password:</label>
            <input type="password" name="password" required>

            <button type="submit" name="assign_teacher">Assign Teacher</button>
        </form>
    </div>
</div>

<!-- Modal for Course Enrollment -->
<div id="studentEnrollmentModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeStudentEnrollmentModal()">&times;</span>
        <h3>Enroll Students</h3>
        <h4 id="course_details"></h4>
        <form method="POST" action="MIS_dashboard.php">
            <input type="hidden" id="edp_code" name="edp_code">
            <input type="hidden" id="course_code" name="course_code">
            <input type="hidden" id="course_description" name="course_description">
            
            <!-- Container for dynamically added student inputs -->
            <div id="studentInputsContainer">
                <input type="text" name="student_to_enroll[]" placeholder="Enter Student ID" required>
            </div>
            
            <button type="button" onclick="addMoreStudentInput()">Add More Student</button>
            <button type="submit" name="enroll_students">Enroll Students</button>
        </form>
    </div>
</div>


<script>
    // function to open Assign Teacher Modal
    function openAssignTeacherModal(edp_code) {
        document.getElementById("edp_code").value = edp_code;
        document.getElementById("assignTeacherModal").style.display = "block";
    }
    // function to close Assign Teacher Modal
    function closeAssignTeacherModal() { document.getElementById("assignTeacherModal").style.display = "none"; }
    function openStudentEnrollmentModal(edp_code, course_code, course_description){
        document.getElementById("studentEnrollmentModal").style.display = "block"
        document.getElementById("course_details").innerHTML = `EDP Code : ${edp_code}`
        document.getElementById("edp_code").value = edp_code
        document.getElementById("course_code").value = course_code
        document.getElementById("course_description").value = course_description
    }
    // Function to add more student input fields
    function addMoreStudentInput() {
        const container = document.getElementById("studentInputsContainer");
        const newInput = document.createElement("input");
        newInput.type = "text";
        newInput.name = "student_to_enroll[]";
        newInput.placeholder = "Enter Student ID";
        newInput.required = true;
        container.appendChild(newInput);
    }

    // Function to reset the modal
    function resetStudentEnrollmentModal() {
        const container = document.getElementById("studentInputsContainer");
        container.innerHTML = '<input type="text" name="student_to_enroll[]" placeholder="Enter Student ID" required>';
    }

    // Function to close and reset the modal
    function closeStudentEnrollmentModal() {
        document.getElementById("studentEnrollmentModal").style.display = "none";
        resetStudentEnrollmentModal();
    }
</script>
</body>
</html>