    <?php
    session_start();
    require __DIR__ . "/../database/connection.php";
    require __DIR__ . "/adminOperations.php";
    require __DIR__ . "/../prompt.php";

    if (!isset($_SESSION['adm_id'])) {
        header("Location: login.php");
        exit();
    }

    $adminOps = new AdminOperations($pdo);

    $section = $_GET['section'] ?? 'users';
    $type = $_GET['type'] ?? 'students';
    $search = $_GET['search'] ?? '';

    // Fetch data based on the selected section
    if ($section === "users") {
        $users = $adminOps->fetchUsers($pdo, $search, $type);

        $tableHeaders = [];
        if ($type === "students") {
            $tableHeaders = ["Student ID", "Name", "Program Enrolled"];
        } elseif ($type === "teachers") {
            $tableHeaders = ["Teacher ID", "Name", "Department"];
        } elseif ($type === "admins") {
            $tableHeaders = ["Admin ID", "Name", "Role"];
        }
    } elseif ($section === "courses") {
        $courses = $adminOps->fetchOfferedCourses($search);
    }
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>MIS Dashboard</title>
        <link rel="icon" type="image/png" href="../logo.png">
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 0;
                background-color: #06a77d;
                color: #052f5f;
            }
            .sidebar {
                width: 250px;
                background-color: #005377;
                color: #d5c67a;
                height: 100vh;
                position: fixed;
                display: flex;
                flex-direction: column;
                gap: 10px;
                padding-top: 20px;
            }
            .sidebar a {
                color: #d5c67a;
                text-decoration: none;
                padding: 15px;
                display: block;
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                transition: background-color 0.3s ease;
            }
            .sidebar a:hover {
                background-color: #d5c67a;
                color: #052f5f;
            }
            .main-content {
                margin-left: 250px;
                padding: 20px;
                background: #f4f9f9;
                min-height: 100vh;
            }
            .search-bar {
                display: flex;
                gap: 10px;
                margin-bottom: 10px;
            }
            .search-bar input, .search-bar select {
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 5px;
            }
            .search-bar button {
                padding: 8px 12px;
                border: none;
                background-color: #005377;
                color: #fff;
                cursor: pointer;
                border-radius: 5px;
            }
            .search-bar button:hover {
                background-color: #d5c67a;
                color: #052f5f;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 15px;
            }
            th, td {
                padding: 10px;
                border: 1px solid #ddd;
                text-align: center;
            }
            th {
                background-color: #d5c67a;
                color: #052f5f;
            }
            .action-btn {
                padding: 6px 12px;
                border: none;
                cursor: pointer;
                border-radius: 5px;
            }
            .assign-teacher {
                background-color: #007BFF;
                color: #fff;
            }
            .assign-teacher:hover {
                background-color: #0056b3;
            }
            .enroll-student {
                background-color: #28A745;
                color: #fff;
            }
            .enroll-student:hover {
                background-color: #1e7e34;
            }
            .modal {
                display: none;
                position: fixed;
                z-index: 1;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.5);
            }
            .modal-content {
                background-color: white;
                margin: 15% auto;
                padding: 20px;
                border: 1px solid #ddd;
                width: 30%;
                text-align: center;
                border-radius: 10px;
            }
            .modal-content form {
                display: flex;
                flex-direction: column;
                gap: 10px;
            }
            .close {
                float: right;
                font-size: 28px;
                font-weight: bold;
                cursor: pointer;
            }
        </style>
    </head>
    <body>

    <div class="sidebar">
        <center><h2>MIS Dashboard</h2></center>
        <a href="MIS_dashboard.php?section=users">Users</a>
        <a href="MIS_dashboard.php?section=courses">Offered Courses</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="main-content">
        <?php if ($section === "users"): ?>
            <h2>Users Management</h2>

            <form method="GET" action="MIS_dashboard.php" class="search-bar">
                <input type="hidden" name="section" value="users">
                <input type="text" name="search" placeholder="Search by ID or Last Name" value="<?= htmlspecialchars($search) ?>">
                <select name="type">
                    <option value="students" <?= $type === "students" ? "selected" : "" ?>>Students</option>
                    <option value="teachers" <?= $type === "teachers" ? "selected" : "" ?>>Teachers</option>
                    <option value="admins" <?= $type === "admins" ? "selected" : "" ?>>Admins</option>
                </select>
                <button type="submit">Search</button>
            </form>

            <table>
                <tr>
                    <?php foreach ($tableHeaders as $header): ?>
                        <th><?= $header ?></th>
                    <?php endforeach; ?>
                </tr>

                <?php foreach ($users as $user): ?>
                    <tr>
                        <?php foreach ($user as $value): ?>
                            <td><?= htmlspecialchars($value) ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
        
        <?php if ($section === "courses"): ?>
            <h2>Offered Courses</h2>

            <form method="GET" action="MIS_dashboard.php" class="search-bar">
                <input type="hidden" name="section" value="courses">
                <input type="text" name="search" placeholder="Search by EDP Code" value="<?= htmlspecialchars($search) ?>">
                <button type="submit">Search</button>
            </form>

            <table>
                <tr>
                    <th>EDP Code</th>
                    <th>Course Code</th>
                    <th>Course Description</th>
                    <th>Schedule</th>
                    <th>Actions</th>
                </tr>

                <?php foreach ($courses as $course): ?>
                    <tr>
                        <td><?= htmlspecialchars($course['edp_code']) ?></td>
                        <td><?= htmlspecialchars($course['course_code']) ?></td>
                        <td><?= htmlspecialchars($course['course_description']) ?></td>
                        <td><?= htmlspecialchars($course['schedule']) ?></td>
                        <td>
                            <button class="action-btn assign-teacher" onclick="openAssignTeacherModal()">Assign Teacher</button>
                            <button class="action-btn enroll-student" onclick="openEnrollStudentModal()">Enroll Students</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>

    <!-- Modal for Assigning Teacher -->
    <div id="assignTeacherModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeAssignTeacherModal()">&times;</span>
            <h3>Assign Teacher</h3>
            <form method="POST">
                <label>EDP Code:
                    <input type="text" id="edp_code" name="edp_code" required>
                </label>
                <label>Teacher ID:
                    <input type="text" id="tc_assigned" name="tc_assigned" required>
                </label>
                <button type="submit">Assign</button>
            </form>
        </div>
    </div>

    <!-- Modal for Enrolling Students -->
    <div id="enrollStudentModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEnrollStudentModal()">&times;</span>
            <h3>Enroll Students</h3>
            <form method="POST">
                <label>EDP Code:
                    <input type="text" id="edp_code_enroll" name="edp_code_enroll" required>
                </label>
                <label>Student ID:
                    <input type="text" id="st_enrolled" name="st_enrolled" required>
                </label>
                <button type="submit">Enroll</button>
            </form>
        </div>
    </div>

    <script>
        function openAssignTeacherModal() { document.getElementById("assignTeacherModal").style.display = "block"; }
        function closeAssignTeacherModal() { document.getElementById("assignTeacherModal").style.display = "none"; }
        function openEnrollStudentModal() { document.getElementById("enrollStudentModal").style.display = "block"; }
        function closeEnrollStudentModal() { document.getElementById("enrollStudentModal").style.display = "none"; }
    </script>
    </body>
    </html>