<?php
function showPrompt($message, $type = "info") {
    echo "
    <div class='prompt-container'>
        <div class='prompt $type'>$message</div>
    </div>
    <script>
        setTimeout(() => {
            document.querySelector('.prompt-container').classList.add('fade-out');
            setTimeout(() => {
                document.querySelector('.prompt-container').remove();
            }, 500);
        }, 3000);
    </script>
    ";
}
?>

<style>
    /* Backdrop effect */
    .prompt-container {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: flex-start;
        padding-top: 5%;
        z-index: 1000;
        transition: opacity 0.5s ease;
    }

    /* Prompt Box */
    .prompt {
        padding: 15px 20px;
        border-radius: 10px;
        text-align: center;
        font-size: 18px;
        font-weight: bold;
        box-shadow: 3px 3px 10px rgba(0, 0, 0, 0.1);
        animation: fadeIn 0.3s ease-in-out;
    }

    /* Message types */
    .success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    .warning { background-color: #fff3cd; color: #856404; border: 1px solid #ffeeba; }
    .info { background-color: #cce5ff; color: #004085; border: 1px solid #b8daff; }

    /* Fade-in Animation */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    /* Fade-out effect */
    .fade-out {
        opacity: 0;
    }
</style>
