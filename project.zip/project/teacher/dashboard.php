<?php
session_start();
require __DIR__ . "/../database/connection.php";
require __DIR__ . "/teacherOperations.php";
require __DIR__ . "/../prompt.php";

if (!isset($_SESSION['tc_id'])) {
    header("Location: login.php");
    exit();
}

$teacherOps = new TeacherOperations($pdo);
$teacher = $teacherOps->getTeacherProfile($_SESSION['tc_id']);
$assignedCourses = $teacherOps->getAssignedCoursesWithSchedule($_SESSION['tc_id']);
$teacher['name'] = $teacher['last_name'] . ", " . $teacher['first_name'];

$activeSection = $_POST['section'] ?? 'dashboard';

// ? Handle profile update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $updated = $teacherOps->updateTeacherProfile($_SESSION['tc_id'], $_POST['first_name'], $_POST['last_name'], $_POST['email']);
    if ($updated) {
        header("Location: teacherDashboard.php");
        exit();
    }
}

// ? Handle password change
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['change_password'])) {
    if (!empty($_POST['new_password'])) {
        $passwordChanged = $teacherOps->changeTeacherPassword($_SESSION['tc_id'], $_POST['new_password']);
        if ($passwordChanged) {
            header("Location: teacherDashboard.php");
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Teacher Dashboard</title>
  <link rel="icon" type="image/png" href="../images/logo.png">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #06a77d;
      color: #052f5f;
      display: flex;
    }
    .sidebar {
      width: 250px;
      background-color: #005377;
      color: #d5c67a;
      height: 100vh;
      position: fixed;
      display: flex;
      flex-direction: column;
      box-shadow: 2px 0 5px rgba(0, 0, 0, 0.2);
      padding-top: 20px;
    }
    .sidebar form {
      display: flex;
      flex-direction: column;
      width: 100%;
    }
    .sidebar button {
      background: none;
      border: none;
      color: #d5c67a;
      text-align: left;
      padding: 15px;
      font-size: 1rem;
      cursor: pointer;
      width: 100%;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      transition: background-color 0.3s ease, transform 0.3s ease;
    }
    .sidebar button:hover, .sidebar button.active {
      background-color: #d5c67a;
      color: #052f5f;
    }
    .logout-button {
      border: 2px solid #d5c67a;
      color: #d5c67a;
      padding: 0.5rem 1rem;
      font-size: 0.9rem;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s ease, color 0.3s ease;
      width: 80%;
      margin: 10% auto;
      text-align: center;
    }
    .logout-button:hover {
      background-color: #d5c67a;
      color: #052f5f;
    }
    .main-content {
      margin-left: 250px;
      padding: 20px;
      width: calc(100% - 250px);
      background: #06a77d;
      border-radius: 12px 0 0 0;
      overflow-y: auto;
    }
    h2 {
      color: #052f5f;
      margin-bottom: 1.5rem;
    }
    .course-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 20px;
    }
    .course-card {
      background-color: #f4f9f9;
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 15px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      text-align: center;
    }
    .course-card h3 {
      margin-top: 0;
      color: #052f5f;
    }
    .course-card p {
      margin: 5px 0;
      color: #005377;
    }
    .open-course-btn {
      margin-top: 10px;
      padding: 10px 15px;
      background-color: #d5c67a;
      color: #052f5f;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      transition: background-color 0.3s ease, transform 0.3s ease;
    }
    .open-course-btn:hover {
      background-color: #b8ab5e;
      transform: scale(1.05);
    }
    .form-container {
      background: #f4f9f9;
      padding: 15px;
      border-radius: 8px;
      margin-top: 15px;
      max-width: 400px;
    }
    .form-container input {
      width: 100%;
      padding: 8px;
      margin-top: 5px;
      border: 1px solid #ddd;
      border-radius: 5px;
    }
    .form-container button {
      margin-top: 10px;
      width: 100%;
      padding: 10px;
      background-color: #d5c67a;
      color: #052f5f;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    .form-container button:hover {
      background-color: #b8ab5e;
    }
  </style>
</head>
<body>
  <div class="sidebar">
  <center><h2>Teacher Dashboard</h2></center>
    <form method="POST">
      <input type="hidden" name="section" value="profile">
      <button type="submit" class="<?php echo ($activeSection === 'profile') ? 'active' : ''; ?>">Your Profile</button>
    </form>
    <form method="POST">
      <input type="hidden" name="section" value="dashboard">
      <button type="submit" class="<?php echo ($activeSection === 'dashboard') ? 'active' : ''; ?>">Dashboard</button>
    </form>
    <form method="POST" action="logout.php">
      <button type="submit" class="logout-button">Logout</button>
    </form>
  </div>

  <div class="main-content">
    <?php if ($activeSection === 'profile'): ?>
      <form method="post">
        <button type="submit" name="edit_profile">Edit Profile</button>
        <button type="submit" name="change_password">Change Password</button>
      </form>
      <div id="profile" class="content">
        <h2>Teacher Profile</h2>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($teacher['name']); ?></p>
        <p><strong>Department:</strong> <?php echo htmlspecialchars($teacher['dept_name']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($teacher['email']); ?></p>
      </div>
    <?php endif; ?>

    <?php if ($activeSection === 'dashboard'): ?>
      <div id="dashboard" class="content">
        <h2>Teacher Dashboard</h2>
        <div class="course-grid">
          <?php if (!empty($assignedCourses)): ?>
            <?php foreach ($assignedCourses as $course): ?>
              <div class="course-card">
                <h3><?php echo htmlspecialchars($course['course_description']) . " (" . htmlspecialchars($course['course_code']) . ")"; ?></h3>
                <p><strong>Schedule:</strong> <?php echo htmlspecialchars($course['schedule']); ?></p>
                <button class="open-course-btn">Open Course</button>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <p>No courses assigned.</p>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>
  </div>
</body>
</html>
