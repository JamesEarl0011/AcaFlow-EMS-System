<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Teacher Dashboard</title>
  <link rel="icon" type="image/png" href="../logo.png">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #06a77d;
      color: #052f5f;
      display: flex;
    }
    .sidebar {
      width: 250px;
      background-color: #005377;
      color: #d5c67a;
      height: 100vh;
      position: fixed;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      box-shadow: 2px 0 5px rgba(0, 0, 0, 0.2);
    }
    .sidebar a {
      color: #d5c67a;
      text-decoration: none;
      padding: 15px;
      display: block;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      transition: background-color 0.3s ease, transform 0.3s ease;
    }
    .sidebar a:hover {
      background-color: #d5c67a;
      color: #052f5f;
      transform: scale(1.02);
    }
    .logout-button {
        background: none;
        border: 2px solid #d5c67a;
        color: #d5c67a;
        padding: 0.5rem 1rem;
        font-size: 0.9rem;
        border-radius: 8px;
        cursor: pointer;
        transition: background-color 0.3s ease, color 0.3s ease;
        width: 80%;
        margin-left: 10%;
    }
    .logout-button:hover {
        background-color: #d5c67a;
        color: #052f5f;
    }
    .main-content {
      margin-left: 250px;
      padding: 20px;
      width: calc(100% - 250px);
      background: #06a77d;
      border-radius: 12px 0 0 0;
      overflow-y: auto;
    }
    h2 {
      color: #052f5f;
      margin-bottom: 1.5rem;
    }
    .course-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 20px;
    }
    .course-card {
      background-color: #f4f9f9;
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 15px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      text-align: center;
    }
    .course-card h3 {
      margin-top: 0;
      color: #052f5f;
    }
    .course-card p {
      margin: 5px 0;
      color: #005377;
    }
    .open-course-btn {
      margin-top: 10px;
      padding: 10px 15px;
      background-color: #d5c67a;
      color: #052f5f;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      transition: background-color 0.3s ease, transform 0.3s ease;
    }
    .open-course-btn:hover {
      background-color: #b8ab5e;
      transform: scale(1.05);
    }
  </style>
</head>
<body>
  <div class="sidebar">
    <div>
      <a onclick="showContent('dashboard')">Dashboard</a>
      <a>Your Profile</a>
      <br><br><br><br><br>
      <button class="logout-button">Logout</button>
    </div>
    
  </div>

  <div class="main-content">
    <!-- Dashboard -->
    <div id="dashboard" class="content active">
      <h2>Teacher Dashboard</h2>
      <div class="course-grid">
        <div class="course-card">
          <h3>Mathematics (MATH101)</h3>
          <p><strong>Department:</strong> Science</p>
          <p><strong>Year Level:</strong> 1</p>
          <button class="open-course-btn">Open Course</button>
        </div>
        <div class="course-card">
          <h3>English (ENG101)</h3>
          <p><strong>Department:</strong> Humanities</p>
          <p><strong>Year Level:</strong> 1</p>
          <button class="open-course-btn">Open Course</button>
        </div>
        <div class="course-card">
          <h3>Physics (PHY101)</h3>
          <p><strong>Department:</strong> Science</p>
          <p><strong>Year Level:</strong> 1</p>
          <button class="open-course-btn">Open Course</button>
        </div>
        <div class="course-card">
          <h3>Chemistry (CHEM101)</h3>
          <p><strong>Department:</strong> Science</p>
          <p><strong>Year Level:</strong> 1</p>
          <button class="open-course-btn">Open Course</button>
        </div>
      </div>
    </div>
  </div>

  <script>
  </script>
</body>
</html>