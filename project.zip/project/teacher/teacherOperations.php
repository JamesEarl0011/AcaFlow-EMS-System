<?php 
require __DIR__ . "/../database/connection.php";

class TeacherOperations {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

// ! Login method
    public function loginTeacher($tc_id, $password) {
        $sql = "SELECT * FROM teachers WHERE tc_id = :tc_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(":tc_id", $tc_id);
        $stmt->execute();
        $teacher = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$teacher) {
            return "Teacher ID not found.";
        }

        if (!password_verify($password, $teacher['hashed_password'])) {
            return "Incorrect password.";
        }

        session_start();
        $_SESSION['tc_id'] = $teacher['tc_id'];
        return true;
    }

// ! method to fetch assigned courses
    public function getAssignedCoursesWithSchedule($tc_id) {
        $sql = "SELECT oc.edp_code, oc.course_code, c.course_description, 
                    CONCAT(oc.scheduled_days, ' (', TIME_FORMAT(oc.scheduled_start, '%h:%i %p'), ' - ', TIME_FORMAT(oc.scheduled_end, '%h:%i %p)')) AS schedule
                FROM assigned_courses ac
                JOIN offered_courses oc ON ac.edp_code = oc.edp_code
                JOIN courses c ON oc.course_code = c.course_code
                WHERE ac.tc_assigned = :tc_id";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(":tc_id", $tc_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }


// ! method to fetch teacher profile
    public function getTeacherProfile($tc_id) {
        $sql = "SELECT 
                    t.last_name, 
                    t.first_name, 
                    d.dept_name, 
                    t.email 
                FROM teachers t
                JOIN departments d ON t.department = d.dept_code
                WHERE t.tc_id = :tc_id";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(":tc_id", $tc_id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

// ! method to update teacher profile
    public function updateTeacherProfile($tc_id, $first_name, $last_name, $email) {
        $sql = "UPDATE teachers SET first_name = :first_name, last_name = :last_name, email = :email WHERE tc_id = :tc_id";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(":first_name", $first_name);
        $stmt->bindParam(":last_name", $last_name);
        $stmt->bindParam(":email", $email);
        $stmt->bindParam(":tc_id", $tc_id);

        return $stmt->execute();
    }

// ! method to change passwrod
    public function changeTeacherPassword($tc_id, $new_password) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $sql = "UPDATE teachers SET hashed_password = :hashed_password WHERE tc_id = :tc_id";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(":hashed_password", $hashed_password);
        $stmt->bindParam(":tc_id", $tc_id);

        return $stmt->execute();
    }

}
?>