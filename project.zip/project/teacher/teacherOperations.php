<?php 
    require __DIR__ . "/../database/connection.php";
    
    class TeacherOperations{
        private $pdo;

        public function __construct($pdo) {
            $this->pdo = $pdo;
        }
// ! Login method
        public function loginTeacher($teacher_number, $password) {
            $sql = "SELECT * FROM teachers WHERE teacher_number = :teacher_number";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(":teacher_number", $teacher_number);
            $stmt->execute();
            $teacher = $stmt->fetch(PDO::FETCH_ASSOC);
        
            if (!$teacher) {
                return "Teacher number not found.";
            }
        
            if (!password_verify($password, $teacher['password'])) {
                return "Incorrect password.";
            }
        
            session_start();
            $_SESSION['teacher_id'] = $teacher['id'];
            $_SESSION['teacher_number'] = $teacher['teacher_number'];
            return true; // Login successful
        }
        
    }
?>