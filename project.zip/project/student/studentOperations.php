<?php 
require __DIR__ . "/../database/connection.php";

class StudentOperations {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

// ! Login method
    public function loginStudent($st_id, $password) {
        $sql = "SELECT * FROM students WHERE st_id = :st_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(":st_id", $st_id);
        $stmt->execute();
        $student = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$student) {
            return "Student ID not found.";
        }

        if (!password_verify($password, $student['hashed_password'])) {
            return "Incorrect password.";
        }

        session_start();
        $_SESSION['st_id'] = $student['st_id'];
        return true;
    }

// ! logout method
    public function logoutStudent() {
        session_unset(); 
        session_destroy();
        header("Location: ../index.php");
        exit();
    }

// ! get user name
    public function getName($st_id) {
        $sqlQuery = "SELECT first_name FROM demographic_profile WHERE st_id = :st_id";
        $stmt = $this->pdo->prepare($sqlQuery);
        $stmt->bindParam(":st_id", $st_id);
        
        if ($stmt->execute()) {
            $name = $stmt->fetch(PDO::FETCH_ASSOC);
            return $name ? $name['first_name'] : "No record found";
        } else {
            return "Failed to fetch student name";
        }
    }


// ! create or update demographic profile
    public function saveDemographicProfile($program_enrolled, $curriculum_year, $first_name, $middle_initial, $last_name, $contact_number, $email, $birthdate, $address, $father_name, $mother_name) {
        $st_id = $_SESSION['st_id'];
    
// ? Check if a profile already exists
        $checkSql = "SELECT profile_id FROM demographic_profile WHERE st_id = :st_id";
        $checkStmt = $this->pdo->prepare($checkSql);
        $checkStmt->bindParam(":st_id", $st_id);
        $checkStmt->execute();
        $existingProfile = $checkStmt->fetch(PDO::FETCH_ASSOC);
    
        if ($existingProfile) {
// ? Update existing profile
            $sql = "UPDATE demographic_profile SET 
                        program_enrolled = :program_enrolled, 
                        curriculum_year = :curriculum_year, 
                        first_name = :first_name, 
                        middle_initial = :middle_initial, 
                        last_name = :last_name, 
                        contact_number = :contact_number, 
                        email = :email, 
                        birthdate = :birthdate, 
                        address = :address, 
                        father_name = :father_name, 
                        mother_name = :mother_name
                    WHERE st_id = :st_id";
        } else {
// ? Insert new profile
            $sql = "INSERT INTO demographic_profile (st_id, program_enrolled, curriculum_year, first_name, middle_initial, last_name, contact_number, email, birthdate, address, father_name, mother_name) 
                    VALUES (:st_id, :program_enrolled, :curriculum_year, :first_name, :middle_initial, :last_name, :contact_number, :email, :birthdate, :address, :father_name, :mother_name)";
        }
    
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(":st_id", $st_id);
        $stmt->bindParam(":program_enrolled", $program_enrolled);
        $stmt->bindParam(":curriculum_year", $curriculum_year);
        $stmt->bindParam(":first_name", $first_name);
        $stmt->bindParam(":middle_initial", $middle_initial);
        $stmt->bindParam(":last_name", $last_name);
        $stmt->bindParam(":contact_number", $contact_number);
        $stmt->bindParam(":email", $email);
        $stmt->bindParam(":birthdate", $birthdate);
        $stmt->bindParam(":address", $address);
        $stmt->bindParam(":father_name", $father_name);
        $stmt->bindParam(":mother_name", $mother_name);
    
        if ($stmt->execute()) {
            return "Profile saved successfully.";
        } else {
            return "Failed to save profile.";
        }
    }
    
// ! method for fetching grade details
    public function getStudentGrades($st_id) {
        $sql = "SELECT g.edp_code, g.course_code, c.course_description AS course_description, 
                    g.midterm_grade, g.final_grade, g.remarks
                FROM grades g
                JOIN courses c ON g.course_code = c.course_code
                WHERE g.st_id = :st_id";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(":st_id", $st_id);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC); // Returns an array of grade records
    }

// ! method for fetching payment status
    public function getPaymentStatus($st_id) {
        $sql = "SELECT midterms_payment_status, finals_payment_status 
                FROM payments 
                WHERE st_id = :st_id";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(":st_id", $st_id);
        $stmt->execute();
        $payment = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$payment) {
            return "No payment record found.";
        }

        if ($payment['midterms_payment_status'] === 'Pending' && $payment['finals_payment_status'] === 'Pending') {
            return "Both midterms and finals have not been paid.";
        } elseif ($payment['midterms_payment_status'] === 'Paid' && $payment['finals_payment_status'] === 'Pending') {
            return "Midterms paid, finals pending.";
        } elseif ($payment['midterms_payment_status'] === 'Paid' && $payment['finals_payment_status'] === 'Paid') {
            return "Both midterms and finals are paid.";
        }

        return "Unknown payment status.";
    }

// ! method for fetching clearance details
    public function getClearanceDetails($st_id) {
        $sql = "SELECT 
                    c.edp_code, 
                    c.course_code, 
                    co.course_description, 
                    CONCAT(t.last_name, ', ', t.first_name) AS teacher_assigned, 
                    c.status 
                FROM clearance c
                JOIN courses co ON c.course_code = co.course_code
                JOIN teachers t ON c.tc_assigned = t.tc_id
                WHERE c.st_id = :st_id";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':st_id', $st_id, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
// ! Fetch course details from offered_courses table
    public function getCourseDetails($edp_code) {
        $stmt = $this->pdo->prepare("
            SELECT oc.edp_code, oc.course_code, c.course_description, c.units, oc.scheduled_days, oc.scheduled_start, oc.scheduled_end, t.first_name, t.last_name
            FROM offered_courses oc
            JOIN courses c ON oc.course_code = c.course_code
            LEFT JOIN assigned_courses ac ON oc.edp_code = ac.edp_code
            LEFT JOIN teachers t ON ac.tc_assigned = t.tc_id
            WHERE oc.edp_code = ?
        ");
        $stmt->execute([$edp_code]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

// ! Check if the student is already enrolled in the course
    public function isStudentEnrolled($st_id, $edp_code) {
        $stmt = $this->pdo->prepare("SELECT * FROM enrollment WHERE st_id = ? AND edp_code = ?");
        $stmt->execute([$st_id, $edp_code]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

// ! Enroll the student in a course
    public function enrollCourse($st_id, $edp_code, $course_code) {
        $stmt = $this->pdo->prepare("INSERT INTO enrollment (st_id, edp_code, course_code) VALUES (?, ?, ?)");
        return $stmt->execute([$st_id, $edp_code, $course_code]);
    }

// ! Fetch enrolled courses for the student
    public function getEnrolledCourses($st_id) {
        $stmt = $this->pdo->prepare("
            SELECT e.edp_code, e.course_code, c.course_description, c.units, oc.scheduled_days, oc.scheduled_start, oc.scheduled_end, t.first_name, t.last_name
            FROM enrollment e
            JOIN offered_courses oc ON e.edp_code = oc.edp_code
            JOIN courses c ON e.course_code = c.course_code
            LEFT JOIN assigned_courses ac ON oc.edp_code = ac.edp_code
            LEFT JOIN teachers t ON ac.tc_assigned = t.tc_id
            WHERE e.st_id = ?
        ");
        $stmt->execute([$st_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
}
?>
