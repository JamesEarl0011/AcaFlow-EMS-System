<?php 
    require __DIR__ . "/../database/connection.php";
    
    class StudentOperations{
        private $pdo;

        public function __construct($pdo) {
            $this->pdo = $pdo;
        }
// ! Login method
        public function loginStudent($student_number, $password) {
            $sql = "SELECT * FROM students WHERE student_number = :student_number";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(":student_number", $student_number);
            $stmt->execute();
            $student = $stmt->fetch(PDO::FETCH_ASSOC);
        
            if (!$student) {
                return "Student number not found.";
            }
        
            if (!password_verify($password, $student['password'])) {
                return "Incorrect password.";
            }
        
            session_start();
            $_SESSION['student_id'] = $student['id'];
            $_SESSION['student_number'] = $student['student_number'];
            return true; // Login successful
        }
        
    }
?>