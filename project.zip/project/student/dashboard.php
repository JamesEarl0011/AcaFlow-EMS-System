<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="icon" type="image/png" href="../logo.png">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #06a77d;
            margin: 0;
            color: #052f5f;
            position: relative;
        }
        .dashboard-container {
            display: flex;
            height: 100vh;
        }
        .sidebar {
            background: #005377;
            width: 180px;
            padding: 1rem;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.2);
            transition: width 0.3s ease, padding 0.3s ease, font-size 0.3s ease;
            overflow: hidden;
            position: relative;
        }
        .sidebar.minimized {
            width: 90px;
            padding: 1rem 0.5rem;
            font-size: 0.8rem;
        }
        .sidebar h2 {
            color: #d5c67a;
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            text-align: center;
            transition: opacity 0.3s ease;
        }
        .sidebar.minimized h2 {
            opacity: 0;
        }
        .sidebar button {
            background: none;
            border: none;
            color: #d5c67a;
            font-size: 1rem;
            padding: 0.75rem 1rem;
            border-radius: 8px;
            margin-bottom: 0.75rem;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
            text-align: center;
        }
        .sidebar.minimized button {
            padding: 0.5rem;
            font-size: 0.8rem;
        }
        .sidebar button:hover {
            background-color: #d5c67a;
            color: #052f5f;
            transform: scale(1.02);
        }
        .main-content {
            flex-grow: 1;
            background: #ffffff;
            padding: 2rem;
            border-radius: 0 12px 0 0;
            overflow-y: auto;
            position: relative;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        .header h1 {
            font-size: 1.75rem;
            color: #052f5f;
        }
        .logout-button {
            background: none;
            border: 2px solid #d5c67a;
            color: #d5c67a;
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        .logout-button:hover {
            background-color: #d5c67a;
            color: #052f5f;
        }
        .card {
            background: #f4f9f9;
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .card h3 {
            color: #052f5f;
            margin-bottom: 1rem;
        }
        .card p {
            color: #005377;
            font-size: 0.95rem;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        th, td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #005377;
            color: #d5c67a;
        }
        tr:hover {
            background-color: #f1f1f1;
        }

        /* Triangle Button */
        .triangle-button {
            position: absolute;
            top: 5%;
            left: 180px;
            width: 0;
            height: 0;
            border-top: 15px solid transparent;
            border-bottom: 15px solid transparent;
            border-right: 20px solid #d5c67a;
            cursor: pointer;
            z-index: 10;
            transition: transform 0.3s ease, left 0.3s ease;
        }
        .triangle-button.flipped {
            transform: scaleX(-1);
        }
        .sidebar.minimized + .triangle-button {
            left: 60px;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div>
                <h2>Student Dashboard</h2>
                <button onclick="location.href='#'">Profile</button>
                <button onclick="location.href='#'">My Grades</button>
                <button onclick="location.href='#'">My Prospectus</button>
                <button onclick="location.href='#'">My Clearance</button>
            </div>
            <button class="logout-button">Logout</button>
        </aside>

        <!-- Triangle Button -->
        <div class="triangle-button" id="toggleButton" onclick="toggleSidebar()"></div>

        <!-- Main Content -->
        <main class="main-content">
            <div class="header">
                <h1>Welcome, Student!</h1>
                <button class="logout-button">Logout</button>
            </div>

            <!-- Grade Portal Section -->
            <div class="card">
                <h3>Grade Portal</h3>
                <p>View your grades for the current semester:</p>
                <table>
                    <thead>
                        <tr>
                            <th>Course Code</th>
                            <th>Course Name</th>
                            <th>Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>MATH101</td>
                            <td>Calculus I</td>
                            <td>A</td>
                        </tr>
                        <tr>
                            <td>ENG101</td>
                            <td>English Composition</td>
                            <td>B+</td>
                        </tr>
                        <tr>
                            <td>PHYS101</td>
                            <td>Physics I</td>
                            <td>A-</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Curriculum Evaluation Section -->
            <div class="card">
                <h3>Curriculum Evaluation</h3>
                <p>Here are the courses offered in your enrolled program:</p>
                <table>
                    <thead>
                        <tr>
                            <th>Course Code</th>
                            <th>Course Name</th>
                            <th>Credits</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>MATH101</td>
                            <td>Calculus I</td>
                            <td>3</td>
                            <td>Completed</td>
                        </tr>
                        <tr>
                            <td>ENG101</td>
                            <td>English Composition</td>
                            <td>3</td>
                            <td>In Progress</td>
                        </tr>
                        <tr>
                            <td>PHYS101</td>
                            <td>Physics I</td>
                            <td>4</td>
                            <td>Not Taken</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Electronic Clearance Section -->
            <div class="card">
                <h3>Electronic Clearance</h3>
                <p>Track your clearance status:</p>
                <table>
                    <thead>
                        <tr>
                            <th>Department</th>
                            <th>Status</th>
                            <th>Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Library</td>
                            <td>Cleared</td>
                            <td>No outstanding books.</td>
                        </tr>
                        <tr>
                            <td>Finance Office</td>
                            <td>Pending</td>
                            <td>Outstanding balance of $50.</td>
                        </tr>
                        <tr>
                            <td>Registrar</td>
                            <td>Cleared</td>
                            <td>All documents submitted.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const toggleButton = document.getElementById('toggleButton');
            sidebar.classList.toggle('minimized');
            toggleButton.classList.toggle('flipped');
        }
    </script>
</body>
</html>