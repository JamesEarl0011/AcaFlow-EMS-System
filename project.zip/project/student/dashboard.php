<?php 
session_start();
ob_start();

require __DIR__ . "/studentOperations.php";
require __DIR__ . "/../database/connection.php";
require __DIR__ . "/../prompt.php";

if (!isset($_SESSION["st_id"])) {
    header("Location: ../login.php");
    exit();
}

$st_id = $_SESSION["st_id"];
$studentOps = new StudentOperations($pdo);
$name = $studentOps->getName($st_id);
$paymentStatus = $studentOps->getPaymentStatus($st_id);

if (is_array($name) && isset($name['first_name'])) {
    $name = $name['first_name'];
} else {
    $name = "Student";
}

// Handle section selection
$section = $_GET['section'] ?? '';

ob_start();
if ($section === 'profile') {
    ?>
    <div class="card">
        <h3>Demographic Profile</h3>
        <form>
            <label>Name: 
                <input type="text" name="last_name" placeholder="Last Name">
                <input type="text" name="first_name" placeholder="First Name">
                <input type="text" name="middle_initial" placeholder="Middle Initial">
            </label><br>
            <label>Program Enrolled: <input type="text" name="program_enrolled" placeholder="Program Enrolled (e.g., BSIT)"></label><br>
            <label>Year Enrolled: <input type="number" name="curriculum_year" placeholder="e.g., 2024"></label><br>
            <label>Contact Number: <input type="text" name="contact_number" placeholder="e.g., 09287794510"></label><br>
            <label>Email: <input type="text" name="email" placeholder="e.g., JohnDoe@example.com"></label><br>
            <label>Birthday: <input type="date" name="birthdate"></label><br>
            <label>Address: <input type="text" name="address"></label><br>
            <label>Father's Name: <input type="text" name="father_name"></label><br>
            <label>Mother's Name: <input type="text" name="mother_name"></label><br>
            <button type="submit">Save</button>
        </form>
    </div>
    <?php
} elseif ($section === 'grades') {
    if ($paymentStatus === "Both midterms and finals have not been paid.") {
        showPrompt("Your account balance has not been paid.", "error");
    } else {
        $grades = $studentOps->getStudentGrades($st_id); // Fetch grades directly from StudentOperations

        ?>
        <div class="card">
            <h3>Grades</h3>
            <table>
                <tr><th>EDP Code</th><th>Course Code</th><th>Course Description</th><th>Midterm</th><th>Final</th><th>Remarks</th></tr>
                <?php
                if (!empty($grades)) {
                    foreach ($grades as $grade) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($grade['edp_code']) . "</td>";
                        echo "<td>" . htmlspecialchars($grade['course_code']) . "</td>";
                        echo "<td>" . htmlspecialchars($grade['course_description']) . "</td>";
                        echo "<td>" . htmlspecialchars($grade['midterm']) . "</td>";

                        // If only midterms are paid, hide final grades
                        if ($paymentStatus === "Only midterms have been paid.") {
                            echo "<td>Not Viewable</td>";
                        } else {
                            echo "<td>" . htmlspecialchars($grade['final']) . "</td>";
                        }

                        echo "<td>" . htmlspecialchars($grade['remarks']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No grades available.</td></tr>";
                }
                ?>
            </table>
        </div>
        <?php
    }
}   elseif ($section === 'clearance') {
        $clearanceDetails = $studentOps->getClearanceDetails($st_id);
        ?>
        <div class="card">
            <h3>Clearance Status</h3>
            <table>
                <tr><th>EDP Code</th><th>Course Code</th><th>Course Description</th><th>Teacher Assigned</th><th>Status</th></tr>
                <?php
                if (!empty($clearanceDetails)) {
                    foreach ($clearanceDetails as $clearance) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($clearance['edp_code']) . "</td>";
                        echo "<td>" . htmlspecialchars($clearance['course_code']) . "</td>";
                        echo "<td>" . htmlspecialchars($clearance['course_description']) . "</td>";
                        echo "<td>" . htmlspecialchars($clearance['teacher_assigned']) . "</td>";
                        echo "<td>" . htmlspecialchars($clearance['status']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No clearance records available.</td></tr>";
                }
                ?>
            </table>
        </div>
        <?php
}   elseif ($section === 'enrollment') {
        ?>
        <div class="card">
            <h3>Enrollment Process</h3>
            <p>Enrollment steps will be displayed here.</p>
        </div>
        <?php
}   elseif ($section === 'prospectus') {
        ?>
        <div class="card">
            <h3>Prospectus</h3>
            <p>Feature not available yet.</p>
        </div>
        <?php
}
$content = ob_get_clean();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="icon" type="image/png" href="../logo.png">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #06a77d;
            margin: 0;
            color: #052f5f;
        }
        .dashboard-container {
            display: flex;
            height: 100vh;
        }
        .sidebar {
            background: #005377;
            width: 180px;
            padding: 1rem;
            display: flex;
            flex-direction: column;
            gap: 30px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.2);
        }
        .sidebar button {
            background: none;
            border: none;
            color: #d5c67a;
            font-size: 1rem;
            padding: 0.75rem;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        .sidebar button:hover {
            background: #d5c67a;
            color: #052f5f;
        }
        .main-content {
            flex-grow: 1;
            background: #ffffff;
            padding: 2rem;
            overflow-y: auto;
        }
        .card {
            background: #f4f9f9;
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #005377;
            color: #d5c67a;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <h2>Student Dashboard</h2>
            <a href="?section=profile"><button>Profile</button></a>
            <a href="?section=grades"><button>My Grades</button></a>
            <a href="?section=prospectus"><button>My Prospectus</button></a>
            <a href="?section=clearance"><button>My Clearance</button></a>
            <a href="?section=enrollment"><button>My Enrollment</button></a>
            <a href="logout.php"><button class="logout-button">Logout</button></a>
        </aside>
        <main class="main-content" id="content">
            <h1>Welcome, <?php echo htmlspecialchars($name); ?></h1>
            <div id="content-area">
                <?php echo $content ?: "<p>Select an option from the sidebar.</p>"; ?>
            </div>
        </main>
    </div>
</body>
</html>
