<?php 
session_start();
ob_start();

require __DIR__ . "/studentOperations.php";
require __DIR__ . "/../database/connection.php";
require __DIR__ . "/../prompt.php";

if (!isset($_SESSION["st_id"])) {
    header("Location: ../login.php");
    exit();
}

$st_id = $_SESSION["st_id"];
$studentOps = new StudentOperations($pdo);
$name = $studentOps->getName($st_id);
$paymentStatus = $studentOps->getPaymentStatus($st_id);

if (is_array($name) && isset($name['first_name'])) {
    $name = $name['first_name'];
} else {
    $name = "Student";
}

// ! Handle enrollment feature
if (!isset($_SESSION['enrollment_step'])) {
    $_SESSION['enrollment_step'] = 1;
}

// ? Handle form display
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (isset($_POST["next"])) {
        if ($_POST["next"] === "part2") {
            $_SESSION['enrollment_step'] = 2;
        } elseif ($_POST["next"] === "part3") {
            $_SESSION['enrollment_step'] = 3;
        } elseif ($_POST["next"] === "back1") {
            $_SESSION['enrollment_step'] = 1;
        } elseif ($_POST["next"] === "back2") {
            $_SESSION['enrollment_step'] = 2;
        }
    }
}


// ? Handle section selection
$section = $_GET['section'] ?? '';

ob_start();
if ($section === 'profile') {
    ?>
    <div class="card">
        <h3>Account Profile</h3>
    </div>
    <?php
        } elseif ($section === 'grades') {
            if ($paymentStatus === "Both midterms and finals have not been paid.") {
                showPrompt("Your account balance has not been paid.", "error");
            } else {
                $grades = $studentOps->getStudentGrades($st_id); // Fetch grades directly from StudentOperations
    ?>
        <div class="card">
            <h3>Grades</h3>
            <table>
                <tr><th>EDP Code</th><th>Course Code</th><th>Course Description</th><th>Midterm</th><th>Final</th><th>Remarks</th></tr>
                <?php
                if (!empty($grades)) {
                    foreach ($grades as $grade) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($grade['edp_code']) . "</td>";
                        echo "<td>" . htmlspecialchars($grade['course_code']) . "</td>";
                        echo "<td>" . htmlspecialchars($grade['course_description']) . "</td>";
                        echo "<td>" . htmlspecialchars($grade['midterm']) . "</td>";

                        // If only midterms are paid, hide final grades
                        if ($paymentStatus === "Only midterms have been paid.") {
                            echo "<td>Not Viewable</td>";
                        } else {
                            echo "<td>" . htmlspecialchars($grade['final']) . "</td>";
                        }

                        echo "<td>" . htmlspecialchars($grade['remarks']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No grades available.</td></tr>";
                }
                ?>
            </table>
        </div>

<?php }} elseif ($section === 'clearance') { $clearanceDetails = $studentOps->getClearanceDetails($st_id); ?>
        <div class="card">
            <h3>Clearance Status</h3>
            <table>
                <tr><th>EDP Code</th><th>Course Code</th><th>Course Description</th><th>Teacher Assigned</th><th>Status</th></tr>
                <?php
                if (!empty($clearanceDetails)) {
                    foreach ($clearanceDetails as $clearance) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($clearance['edp_code']) . "</td>";
                        echo "<td>" . htmlspecialchars($clearance['course_code']) . "</td>";
                        echo "<td>" . htmlspecialchars($clearance['course_description']) . "</td>";
                        echo "<td>" . htmlspecialchars($clearance['teacher_assigned']) . "</td>";
                        echo "<td>" . htmlspecialchars($clearance['status']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No clearance records available.</td></tr>";
                }
                ?>
            </table>
        </div>
<?php } elseif ($section === 'enrollment') { ?>
        <?php if ($_SESSION['enrollment_step'] == 1) : ?>
            <!-- Part 1: Personal Information -->
            <div class="card">
                <h3>Enrollment Form - Part 1: Personal Information</h3>
                <form method="POST">
                    <label>First Name: <input type="text" name="first_name" required></label><br>
                    <label>Last Name: <input type="text" name="last_name" required></label><br>
                    <label>Middle Initial: <input type="text" name="middle_initial"></label><br>
                    <label>Gender:
                        <select name="gender">
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </label><br>
                    <label>Date of Birth: <input type="date" name="date_of_birth"></label><br>
                    <label>Nationality: <input type="text" name="nationality"></label><br>
                    <button type="submit" name="next" value="part2">Next</button>
                </form>
            </div>

        <?php elseif ($_SESSION['enrollment_step'] == 2) : ?>
            <!-- Part 2: Academic & Contact Information -->
            <div class="card">
                <h3>Enrollment Form - Part 2: Academic & Contact Information</h3>
                <form method="POST">
                    <label>Program Enrolled: <input type="text" name="program_enrolled" required></label><br>
                    <label>Year Level: <input type="number" name="year_level" required></label><br>
                    <label>Mobile Number: <input type="text" name="mobile_number"></label><br>
                    <label>Email: <input type="email" name="email" required></label><br>
                    <label>Supporting Studies:
                        <select name="supporting_studies">
                            <option value="Parents">Parents</option>
                            <option value="Self Supporting">Self Supporting</option>
                        </select>
                    </label><br>
                    <button type="submit" name="next" value="part3">Next</button>
                </form>
                <form method="POST">
                    <button type="submit" name="next" value="back1">Back</button>
                </form>
            </div>

        <?php elseif ($_SESSION['enrollment_step'] == 3) : ?>
            <!-- Part 3: Course Enrollment -->
            <div class="card">
                <h3>Enrollment Form - Part 3: Course Enrollment</h3>
                <form method="POST">
                    <button type="submit" name="next" value="back2">Back</button>
                </form>
                <form method="POST">
                    <label>EDP Code: <input type="text" name="edp_code" required></label>
                    <label>Course: <input type="text" name="course_description" disabled></label>
                    <button type="button" id="search_course">Search Course</button>
                    <button type="submit" name="enroll_course">Enroll Course</button>
                </form>

                <h4>Enrolled Courses</h4>
                <table>
                    <thead>
                        <tr>
                            <th>EDP Code</th>
                            <th>Course Code</th>
                            <th>Course Description</th>
                            <th>Units</th>
                            <th>Schedule</th>
                            <th>Teacher Assigned</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $enrolledCourses = $studentOps->getEnrolledCourses($st_id);
                        if (!empty($enrolledCourses)) {
                            foreach ($enrolledCourses as $course) {
                                echo "<tr>";
                                echo "<td>" . htmlspecialchars($course['edp_code']) . "</td>";
                                echo "<td>" . htmlspecialchars($course['course_code']) . "</td>";
                                echo "<td>" . htmlspecialchars($course['course_description']) . "</td>";
                                echo "<td>" . htmlspecialchars($course['units']) . "</td>";
                                echo "<td>" . htmlspecialchars($course['scheduled_days']) . " " . htmlspecialchars($course['scheduled_start']) . " - " . htmlspecialchars($course['scheduled_end']) . "</td>";
                                echo "<td>" . htmlspecialchars($course['teacher_name']) . "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='6'>No courses enrolled yet.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
<?php }   elseif ($section === 'prospectus') {  ?>
        <div class="card">
            <h3>Prospectus</h3>
            <p>Feature not available yet.</p>
        </div>
<?php } $content = ob_get_clean(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="icon" type="image/png" href="../images/logo.png">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #06a77d;
            margin: 0;
            color: #052f5f;
        }
        .dashboard-container {
            display: flex;
            height: 100vh;
        }
        .sidebar {
            background: #005377;
            width: 180px;
            padding: 1rem;
            display: flex;
            flex-direction: column;
            gap: 30px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.2);
        }
        .sidebar button {
            background: none;
            border: none;
            color: #d5c67a;
            font-size: 1rem;
            padding: 0.75rem;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        .sidebar button:hover {
            background: #d5c67a;
            color: #052f5f;
        }
        .main-content {
            flex-grow: 1;
            background: #ffffff;
            padding: 2rem;
            overflow-y: auto;
        }
        .card {
            background: #f4f9f9;
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #005377;
            color: #d5c67a;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <center><h2>Student Dashboard</h2></center>
            <a href="?section=profile"><button>Profile</button></a>
            <a href="?section=grades"><button>My Grades</button></a>
            <a href="?section=prospectus"><button>My Prospectus</button></a>
            <a href="?section=clearance"><button>My Clearance</button></a>
            <a href="?section=enrollment"><button>My Enrollment</button></a>
            <a href="logout.php"><button class="logout-button">Logout</button></a>
        </aside>
        <main class="main-content" id="content">
            <h1>Welcome, <?php echo htmlspecialchars($name); ?></h1>
            <div id="content-area">
                <?php echo $content ?: "<p>Select an option from the sidebar.</p>"; ?>
            </div>
        </main>
    </div>
</body>
</html>
