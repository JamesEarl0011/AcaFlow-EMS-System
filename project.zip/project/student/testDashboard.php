<?php
session_start();
ob_start();

require __DIR__ . "/studentOperations.php";
require __DIR__ . "/../database/connection.php";
require __DIR__ . "/../prompt.php";

$studentOps = new StudentOperations($pdo);
$st_id = "23079569";

// Initialize session step if not set
if (!isset($_SESSION['enrollment_step'])) {
    $_SESSION['enrollment_step'] = 1;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (isset($_POST["next"])) {
        if ($_POST["next"] === "part2") {
            $_SESSION['enrollment_step'] = 2;
        } elseif ($_POST["next"] === "part3") {
            $_SESSION['enrollment_step'] = 3;
        } elseif ($_POST["next"] === "back1") {
            $_SESSION['enrollment_step'] = 1;
        } elseif ($_POST["next"] === "back2") {
            $_SESSION['enrollment_step'] = 2;
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enrollment Form</title>
</head>
<style>
    /* General Styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
}

/* Card Container */
.card {
    background: #fff;
    padding: 20px;
    margin: 20px;
    width: 90%;
    max-width: 600px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

h3 {
    color: #333;
    text-align: center;
}

/* Form Styles */
form {
    display: flex;
    flex-direction: column;
}

label {
    font-weight: bold;
    margin-top: 10px;
}

input, select {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
}

button {
    background-color: #007BFF;
    color: white;
    padding: 10px;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    margin-top: 15px;
}

button:hover {
    background-color: #0056b3;
}

/* Table Styling */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 10px;
    text-align: left;
}

th {
    background-color: #007BFF;
    color: white;
}

td {
    background-color: #fff;
}

@media (max-width: 768px) {
    .card {
        width: 95%;
    }
}

</style>
<body>

<?php if ($_SESSION['enrollment_step'] == 1) : ?>
    <!-- Part 1: Personal Information -->
    <div class="card">
        <h3>Enrollment Form - Part 1: Personal Information</h3>
        <form method="POST">
            <label>First Name: <input type="text" name="first_name" required></label><br>
            <label>Last Name: <input type="text" name="last_name" required></label><br>
            <label>Middle Initial: <input type="text" name="middle_initial"></label><br>
            <label>Gender:
                <select name="gender">
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </label><br>
            <label>Date of Birth: <input type="date" name="date_of_birth"></label><br>
            <label>Nationality: <input type="text" name="nationality"></label><br>
            <button type="submit" name="next" value="part2">Next</button>
        </form>
    </div>

<?php elseif ($_SESSION['enrollment_step'] == 2) : ?>
    <!-- Part 2: Academic & Contact Information -->
    <div class="card">
        <h3>Enrollment Form - Part 2: Academic & Contact Information</h3>
        <form method="POST">
            <label>Program Enrolled: <input type="text" name="program_enrolled" required></label><br>
            <label>Year Level: <input type="number" name="year_level" required></label><br>
            <label>Mobile Number: <input type="text" name="mobile_number"></label><br>
            <label>Email: <input type="email" name="email" required></label><br>
            <label>Supporting Studies:
                <select name="supporting_studies">
                    <option value="Parents">Parents</option>
                    <option value="Self Supporting">Self Supporting</option>
                </select>
            </label><br>
            <button type="submit" name="next" value="part3">Next</button>
        </form>
        <form method="POST">
            <button type="submit" name="next" value="back1">Back</button>
        </form>
    </div>

<?php elseif ($_SESSION['enrollment_step'] == 3) : ?>
    <!-- Part 3: Course Enrollment -->
    <div class="card">
        <h3>Enrollment Form - Part 3: Course Enrollment</h3>
        <form method="POST">
            <button type="submit" name="next" value="back2">Back</button>
        </form>
        <form method="POST">
            <label>EDP Code: <input type="text" name="edp_code" required></label>
            <label>Course: <input type="text" name="course_description" disabled></label>
            <button type="button" id="search_course">Search Course</button>
            <button type="submit" name="enroll_course">Enroll Course</button>
        </form>

        <h4>Enrolled Courses</h4>
        <table>
            <thead>
                <tr>
                    <th>EDP Code</th>
                    <th>Course Code</th>
                    <th>Course Description</th>
                    <th>Units</th>
                    <th>Schedule</th>
                    <th>Teacher Assigned</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $enrolledCourses = $studentOps->getEnrolledCourses($st_id);
                if (!empty($enrolledCourses)) {
                    foreach ($enrolledCourses as $course) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($course['edp_code']) . "</td>";
                        echo "<td>" . htmlspecialchars($course['course_code']) . "</td>";
                        echo "<td>" . htmlspecialchars($course['course_description']) . "</td>";
                        echo "<td>" . htmlspecialchars($course['units']) . "</td>";
                        echo "<td>" . htmlspecialchars($course['scheduled_days']) . " " . htmlspecialchars($course['scheduled_start']) . " - " . htmlspecialchars($course['scheduled_end']) . "</td>";
                        echo "<td>" . htmlspecialchars($course['teacher_name']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No courses enrolled yet.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

</body>
</html>
