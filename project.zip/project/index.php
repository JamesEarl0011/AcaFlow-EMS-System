<?php
session_start();
require __DIR__ . "/database/connection.php";
require __DIR__ . "/prompt.php";
require __DIR__ . "/admin/adminOperations.php";
require __DIR__ . "/teacher/teacherOperations.php";
require __DIR__ . "/student/studentOperations.php";

$studentOps = new StudentOperations($pdo);
$teacherOps = new TeacherOperations($pdo);
$adminOps = new AdminOperations($pdo);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $role = $_POST['role'] ?? '';
    $username = $_POST['student_number'] ?? $_POST['teacher_number'] ?? $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    //* Handle login based on role
    switch ($role) {
        case "student":
            $loginResult = $studentOps->loginStudent($username, $password);
            if ($loginResult === true) {
                $_SESSION["st_id"] = $username;
                header("Location: student/dashboard.php");
                exit;
            }
            break;
        case "teacher":
            $loginResult = $teacherOps->loginTeacher($username, $password);
            if ($loginResult === true) {
                $_SESSION["tc_id"] = $username;
                header("Location: teacher/dashboard.php");
                exit;
            }
            break;
        case "admin":
            $loginResult = $adminOps->loginAdmin($username, $password);
            if ($loginResult === true) {
                $_SESSION["adm_id"] = $username;
                header("Location: admin/dashboard.php");
                exit;
            }
            break;
        default:
            $loginResult = "Invalid role.";
    }

    showPrompt($loginResult, "error");
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AcaFlow Login</title>
    <link rel="icon" type="image/png" href="logo.png">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #06a77d;
            margin: 0;
            color: #052f5f;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-container {
            background: #005377;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 6px 10px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
        }
        .nav-tabs {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .nav-tabs button {
            background: none;
            border: none;
            color: #d5c67a;
            font-size: 1rem;
            padding: 0.5rem 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            border-radius: 8px;
        }
        .nav-tabs button.active {
            background-color: #d5c67a;
            color: #052f5f;
        }
        .nav-tabs button:hover:not(.active) {
            background-color: rgba(213, 198, 122, 0.2);
        }
        .form-container {
            display: none;
        }
        .form-container.active {
            display: block;
        }
        .inp {
            margin-bottom: 1.25rem;
        }
        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #d5c67a;
        }
        .password-wrapper {
            position: relative;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 0.85rem;
            font-size: 1rem;    
            border: none;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            transition: background-color 0.3s ease;
        }
        input::placeholder {
            color: #9e9e9e;
        }
        input:focus {
            background: rgba(255, 255, 255, 0.2);
            outline: none;
        }
        button[type="submit"] {
            background-color: #d5c67a;
            color: #052f5f;
            border: none;
            padding: 0.9rem;
            font-size: 1rem;
            border-radius: 8px;
            cursor: pointer;
            width: 100%;
            margin-bottom: 0.75rem;
            transition: background-color 0.3s ease;
        }
        button[type="submit"]:hover {
            background-color: #b8ab5e;
        }
        .show-password-icon {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            width: 20px; 
            height: 20px; 
            cursor: pointer;
            opacity: 0.7; 
            transition: opacity 0.3s ease;
        }
        .show-password-icon:hover {
            opacity: 1;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <!-- Navigation Tabs -->
        <div class="nav-tabs">
            <button onclick="showForm('student')" class="active">Student</button>
            <button onclick="showForm('teacher')">Teacher</button>
            <button onclick="showForm('admin')">Admin</button>
        </div>

        <!-- Student Login Form -->
        <form method="post" class="form-container active">
            <input type="hidden" name="role" value="student">
            <div class="inp">
                <label for="student_number">ID number</label>
                <input type="text" name="student_number" id="student_number" placeholder="Enter your ID number" required>
            </div>
            <div class="inp">
                <label for="student_password">Password</label>
                <div class="password-wrapper">
                    <input type="password" name="password" id="student_password" placeholder="Enter your password" required>
                    <img src="images/show_password_icon.png" alt="Show Password" class="show-password-icon" onclick="togglePassword('student_password')">
                </div>
            </div>
            <button type="submit">Login as Student</button>
        </form>

        <!-- Teacher Login Form -->
        <form method="post" class="form-container">
            <input type="hidden" name="role" value="teacher">
            <div class="inp">
                <label for="teacher_number">ID number</label>
                <input type="text" name="teacher_number" id="teacher_number" placeholder="Enter your ID number" required>
            </div>
            <div class="inp">
                <label for="teacher_password">Password</label>
                <div class="password-wrapper">
                    <input type="password" name="password" id="teacher_password" placeholder="Enter your password" required>
                    <img src="images/show_password_icon.png" alt="Show Password" class="show-password-icon" onclick="togglePassword('teacher_password')">
                </div>
            </div>
            <button type="submit">Login as Teacher</button>
        </form>

        <!-- Admin Login Form -->
        <form method="post" class="form-container">
            <input type="hidden" name="role" value="admin">
            <div class="inp">
                <label for="admin_username">Admin ID</label>
                <input type="text" name="username" id="admin_username" placeholder="Enter your username" required>
            </div>
            <div class="inp">
                <label for="admin_password">Password</label>
                <div class="password-wrapper">
                    <input type="password" name="password" id="admin_password" placeholder="Enter your password" required>
                    <img src="images/show_password_icon.png" alt="Show Password" class="show-password-icon" onclick="togglePassword('admin_password')">
                </div>
            </div>
            <button type="submit">Login as Admin</button>
        </form>
    </div>

    <script>
        function showForm(formType) {
            // Remove active class from all tabs
            document.querySelectorAll('.nav-tabs button').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Hide all forms
            document.querySelectorAll('.form-container').forEach(form => {
                form.classList.remove('active');
            });
            
            // Show selected form and mark tab as active
            if (formType === 'student') {
                document.querySelector('form:nth-child(2)').classList.add('active');
                document.querySelector('.nav-tabs button:first-child').classList.add('active');
            } else if (formType === 'teacher') {
                document.querySelector('form:nth-child(3)').classList.add('active');
                document.querySelector('.nav-tabs button:nth-child(2)').classList.add('active');
            } else if (formType === 'admin') {
                document.querySelector('form:nth-child(4)').classList.add('active');
                document.querySelector('.nav-tabs button:last-child').classList.add('active');
            }
        }

        // Toggle Password Visibility
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);

            if (input.type === "password") {
                input.type = "text";
            } else {
                input.type = "password";
            }
        }
    </script>
</body>
</html>