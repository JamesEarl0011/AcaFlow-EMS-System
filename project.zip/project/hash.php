<?php 
    echo password_hash("123qwe", PASSWORD_DEFAULT);
?>