<?php 
    echo password_hash("Accounting123", PASSWORD_DEFAULT);
?>