<?php 
    echo password_hash("MIS1", PASSWORD_DEFAULT);
?>